import Request from "./Request";

export default class User{

    static getCurrentInspection(callback, error_callback) {
        Request.get(`user/driver/inspection`, {},
            callback,
            function (error) {
                console.log('Error', error);
                error_callback(error);
            });
    }
}