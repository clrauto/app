import Request from "./Request";
import DataManager from "../DataManager";
import {Alert} from "react-native";

export default class Auth{
    /**
     * Login
     *
     * @param email
     * @param password
     * @param callback
     * @param error_callback
     */
    static login(email, password, callback, error_callback)
    {
        Request.raw(
            'auth/login',
            {
                'email': email,
                'password': password,
            },
            function(responseObject){
                DataManager.shared().setAuthorization(
                    responseObject.access_token,
                    function(){
                        DataManager.shared().setAuthenticatedUser(
                            responseObject.user.id,
                            responseObject.user.name,
                            email,
                            function(){
                                callback(responseObject);
                            }
                        );

                    }
                );

            }, function(error){
                console.log('Error:', error)
                Alert.alert("Invalid username/password combination");
                error_callback();
            }
        );
    }

    /**
     * Register
     *
     * @param name
     * @param email
     * @param password
     * @param phone_number
     * @param allow_calls
     * @param callback
     */
    register(name, email, password, phone_number = null, allow_calls = false, callback)
    {
        Request.raw(
            'api/register', {
                'name' : name,
                'email': email,
                'password': password,
                'c_password': password,
            },
            function(responseObject){

                DataManager.shared().setAuthorization(
                    responseObject.success.token,
                    function(){

                        DataManager.shared().setAuthenticatedUser(
                            responseObject.success.id,
                            responseObject.success.name,
                            responseObject.success.email,
                            function(){
                                callback(responseObject.success.token);
                            }
                        );

                    }
                );

            }, function(error){

                var error_string = null;

                Object.keys(error.error).map(function(key){

                    if(!error_string){
                        error_string = error.error[key][0];
                    }

                });

                Alert.alert(error_string);

            }
        );
    }

    update(name = null, password = null, phone_number = null, allow_calls = null, callback)
    {
        var self = this;
        var object = {};

        if(name != null){ object.name = name; }
        if(password != null){ object.password = password; }

        Request.put('me', {data : object}, function(responseObject){

            self.me(function(user){

                DataManager.shared().setAuthenticatedUser(
                    responseObject.id,
                    responseObject.name,
                    responseObject.email,
                    function(){
                        callback(responseObject);
                    }
                );

            })

        }, function(error){

            var error_string = null;

            Object.keys(error.errors).map(function(key){

                if(!error_string){
                    error_string = error.errors[key][0];
                }

            });

            Alert.alert(error_string);

        })
    }

    /**
     * Get Authenticated Users Information
     *
     * @param callback
     */
    me(callback)
    {
        Request.get('auth/me', {}, callback, function () {
            console.log('Error')
        })
    }

    static passwordEmail(email, callback, error_callback)
    {
        Request.raw(
            'auth/password/email',
            {
                'email': email,
            },
            function(response) {
                callback(response);
            }, function(error) {
                console.log('Error:', error)
                Alert.alert("Something went wrong, please try again.");
                error_callback(error);
            }
        );
    }
}
