import DataManager from "../DataManager";
import Config from "../Config";
import {Alert} from "react-native";

export default class Request
{
    /**
     * GET
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     */
    static get(url, params, callback, error_callback){
        Request.main( url, params, callback, error_callback, "GET");
    }

    /**
     * POST
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     */
    static post(url, params, callback, error_callback){
        Request.main( url, params, callback, error_callback, "POST");
    }

    /**
     * PUT
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     */
    static put(url, params, callback, error_callback){
        Request.main( url, params, callback, error_callback, "PUT");
    }

    /**
     * DELETE
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     */
    static delete(url, params, callback, error_callback){
        Request.main( url, params, callback, error_callback, "DELETE");
    }

    /**
     * REQUEST
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     * @param type
     */
    static main(url, params, callback, error_callback, type = "POST")
    {
        DataManager.shared().getAccessToken(function(access_token){
            if(access_token){

                Request.raw(url, params, callback, error_callback, type, {
                    'Authorization' : 'Bearer ' + access_token
                })

            }else{

                Request.raw(url, params, callback, error_callback, type)

            }

        });
    }

    /**
     * Raw Request
     *
     * @param url
     * @param params
     * @param callback
     * @param error_callback
     * @param type
     * @param headers
     * @private
     */
    static raw(url, params, callback, error_callback, type = 'POST', headers = {})
    {
        fetch(Config.serverUrl + url, {
            method: type,
            headers: {...headers, ...{
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                }},
            body: (type != 'GET' ? JSON.stringify(params) : null),
            })
            .then(response => {
                const statusCode = response.status;
                const data = response.json();
                return Promise.all([statusCode, data]);
            })
            .then(array => {
                if(array[0] !== 200 && array[0] !== 201) {
                    throw array[1];
                }
                callback(array[1]);
            })
            .catch(error => {
                //console.log('CatchError:', error)
                if(typeof error_callback === 'function'){
                    error_callback(error)

                }else{

                    if(typeof error.hint !== 'undefined'){
                        alert(error.hint);
                        return;
                    }
                }

            })
    }

    static post_form(url, params, images, callback, error_callback)
    {
        DataManager.shared().getAccessToken(function(access_token){
            let body = new FormData();
            body.append('id', params.items ? null : params.id)

            if(params.driver_signature != null) { body.append('driver_signature', params.driver_signature) }

            if(params.receiver_signature != null) { body.append('receiver_signature', params.receiver_signature) }

            if(params.driver_name != null) { body.append('driver_name', params.driver_name) }

            if(params.receiver_name != null) { body.append('receiver_name', params.receiver_name) }

            if (params.work_order_id != null) { body.append('work_order_id', params.work_order_id) }

            if(params && params.hasOwnProperty('inputs')  && params.inputs) {
                params.items.map((object, index) => {
                    body.append('items[]', JSON.stringify({
                        inspection_item_id: object.id,
                        input: object.input,
                        damage_input: object.damage_input,
                        file_path: object.file_path,
                        additional_input: object.additional_input
                    }));
                    if(object.file) {
                        body.append(`file_${object.id}`, object.file);
                    }
                });
            }

            if(images && images.length > 0){
                images.map((object, index) => {
                    if(params && params.hasOwnProperty('pictures_input')) {
                        body.append('pictures[]', object);
                        body.append('picture_info[]', JSON.stringify({name: object.image_name, description: object.description}))
                    } else {
                        body.append(object.column, object);
                    }
                });
            }

            Request.sendForm(access_token, url, body, callback, error_callback);
        });
    }

    static post_image(url, photo, callback, error_callback)
    {
        DataManager.shared().getAccessToken(function(access_token){
            let body = new FormData()
            body.append(photo.column, photo);
            if (photo.hasOwnProperty('description')) {
                body.append('picture_info', JSON.stringify({name: photo.image_name, description: photo.description}));
            }
            Request.sendForm(access_token, url, body, callback, error_callback);
        });
    }

    static sendForm(access_token, url, body, callback, error_callback) {
        if(access_token) {
            fetch(Config.serverUrl + url, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'multipart/form-data',
                    'Authorization': 'Bearer ' + access_token
                },
                body,
            })
                .then(response => {

                    const statusCode = response.status;
                    const data = response.json();

                    return Promise.all([statusCode, data]);

                })
                .then(([status, data]) => {

                    if ( status !== 200 && status !== 201) {
                        console.log("Error From SDK: " + status, data);

                        if ( status === 403 ) {
                            setTimeout(() => {
                                Alert.alert("This action is unauthorized.");
                            }, 100);
                        }

                        error_callback(data);
                        return;
                    }

                    callback(data);

                })

                .catch(error => {
                    console.log("Error From POST FORM: ", error);
                    error_callback(error);

                });
        }
    }
}
