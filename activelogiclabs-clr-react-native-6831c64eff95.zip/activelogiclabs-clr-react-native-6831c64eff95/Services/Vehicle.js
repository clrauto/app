import Request from "./Request";
import {Alert} from "react-native";

export default class Vehicle{

    static getByVin(vin, callback, error_callback) {
        Request.get(`vehicle-vin/${vin}`, {},
            callback,
            function (error) {
            console.log('Error: ', error)
            error_callback(error)
        })
    }

    static setLocation(vin, location) {
        Request.post(`vehicle/location`, {
            vin: vin,
            location: location
            },
            function () {

            },
            function (error) {
                console.log('Error', error)
            }
        )
    }

    static changeStatus(vehicle_id, workOrder_id, item, callback, error_callback) {
        Request.post(`vehicle/${vehicle_id}/workOrder/${workOrder_id}/status`, {
                status: item.value,
                reason: item.reason,
                shop_name: item.shopName
            },
            function (response) {
                callback(response)
            },
            function (error) {
                console.log('Error', error)
                Alert.alert("Something went wrong, please try again... ")
                error_callback(error)
            }
        )
    }

    static update(id, params, callback = null, error_callback = null) {
        Request.put(`vehicle/${id}`, params,
            function (response) {
                if(typeof callback === 'function'){
                    callback(response)
                }
            },
            function (error) {
                console.log('Error', error)
                if(typeof error_callback === 'function'){
                    error_callback(error)
                }
            }
        )
    }

    static setYard(id, params, callback = null, error_callback = null) {
        Request.put(`vehicle/${id}/yard/${params.yard_id}`, params,
            function (response) {
                if(typeof callback === 'function'){
                    callback(response)
                }
            },
            function (error) {
                console.log('Error', error)
                if(typeof error_callback === 'function'){
                    error_callback(error)
                }
            }
        )
    }

    static detach(id, callback, error_callback = null) {
        Request.put(`workOrder/${id}/detach`, {},
            function (response) {
                if(typeof callback === 'function'){
                    callback(response)
                }
            },
            function (error) {
                console.log('Error', error)
                if(typeof error_callback === 'function'){
                    error_callback(error)
                }
            })
    }
}
