import Request from "./Request";
import DataManager from "../DataManager";
import {Alert} from "react-native";

export default class Inspection{

    static getYards(callback, error_callback) {
        Request.get(`yards`, {},
            callback,
            function (error) {
                console.log('Error', error)
                error_callback(error)
            })
    }

    static get(id, callback)
    {
        Request.get(
            `inspection/${id}`,
            {},
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
            }
        );
    }

    static store(inspection, callback, error_callback)
    {
        Request.post(
            'inspection',
            inspection,
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }

    static inputs(inspection_id, items, callback, error_callback)
    {
        Request.post_form(
            `inspection/${inspection_id}/inputs`,
            {items: items,
                    inputs: true},
            null,
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }

    static update(inspection, images, callback, error_callback)
    {
        Request.post_form(
            `inspection/${inspection.id}`,
            inspection,
            images,
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }

    static add_pictures(inspection, photo, callback, error_callback)
    {
        Request.post_image(
            `inspection/${inspection.id}/pictures`,
            photo,
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }

    static uploadPhoto(inspection, photo, callback, error_callback)
    {
        Request.post_image(
            `inspection/${inspection.id}`,
            photo,
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }

    static cancel(id, callback, error_callback)
    {
        Request.delete(
            `inspection/${id}`,
            {},
            function(response){
                callback(response)
            }, function(error){
                console.log('Error:', error)
                error_callback();
            }
        );
    }
}
