import Auth from './Auth'

const SDK = {
    get Auth(){ return Auth}
};

export default SDK

