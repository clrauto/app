import AsyncStorage from '@react-native-async-storage/async-storage';

export default class DataManager
{
    static instance = null;

    location = null;
    distance = 5;
    time = null;

    /**
     * @returns {DataManager}
     */
    static shared()
    {
        if (DataManager.instance == null) {
            DataManager.instance = new DataManager();
        }

        return this.instance;
    }

    /**
     * Get Access Token
     *
     * @param callback
     */
    getAccessToken(callback)
    {
        AsyncStorage.getItem('auth').then((res) => {
            res = JSON.parse(res);
            callback(res ? res.access_token : null);
        });
    }

    /**
     * Get User Object
     *
     * @param callback
     */
    getUserObject(callback)
    {
        AsyncStorage.getItem('user').then((res) => {
            res = JSON.parse(res);
            callback(res ? res : null);
        });
    }

    /**
     * Set Authorization
     *
     * @param access_token
     * @param callback
     */
    setAuthorization(access_token, callback)
    {
        var self = this;
        if(!access_token){
            alert("No auth token provided to set authorization]");
        }
        AsyncStorage.setItem('auth', JSON.stringify({
            'access_token': access_token,
        })).then(() => {
            callback();
        });

    }

    /**
     * Set Authenticated User
     *
     * @param id
     * @param name
     * @param email
     * @param phone_number
     * @param callback
     */
    setAuthenticatedUser(id, name, email, callback)
    {
        var self = this;
        AsyncStorage.removeItem('user').then(() => {
            AsyncStorage.setItem('user', JSON.stringify({
                'id': id,
                'name': name,
                'email': email
            })).then(() => {
                callback();
            });

        });
    }

    /**
     * Unset Authorization
     *
     * @param callback
     */
    unsetAuthorization(callback)
    {
        AsyncStorage.removeItem('auth').then(() => {
            AsyncStorage.removeItem('user').then(() => {
                callback();
            })
        });
    }

    /**
     * Check if user exists, run proper callback
     *
     * @param yesCallback
     * @param noCallback
     * @returns {*}
     */
    static userExists(yesCallback = null, noCallback = null)
    {
        AsyncStorage.getItem('auth').then((res) => {

            if(res != null){

                if(typeof yesCallback == 'function'){
                    yesCallback();
                }

            }else{

                if(typeof noCallback == 'function'){
                    return noCallback();
                }

            }

        });
    }

    /**
     * Set Yard
     *
     * @param id_yard
     */
    setYard(yard, callback)
    {
        AsyncStorage.setItem('yard', JSON.stringify({
            'yard': yard,
        })).then(() => {
            callback();
        });

    }

    /**
     * Get Yard Object
     *
     * @param callback
     */
    getYardObject(callback)
    {
        AsyncStorage.getItem('yard').then((res) => {
            res = JSON.parse(res);
            callback(res ? res : null);
        });
    }


}
