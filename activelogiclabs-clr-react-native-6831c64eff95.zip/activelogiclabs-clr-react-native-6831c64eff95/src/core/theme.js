import { DefaultTheme } from 'react-native-paper'

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    text: '#000000',
    textWhite: '#FFF',
    primary: '#1d6db3',
    secondary: '#0f4a7d',
    gray: '#606165',
    error: '#f13a59',
    lightgray: '#e7e9ea',
    lightgrayb: '#d0d1d2',
    green: '#6fad84',
    gradient: '#2079C6',
    gradient2: '#5ec695'
  },
}
