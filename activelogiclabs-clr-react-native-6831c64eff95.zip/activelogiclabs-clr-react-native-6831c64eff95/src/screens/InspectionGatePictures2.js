import React, {useReducer, useState} from 'react'
import {
    StyleSheet,
    View,
    Text,
    SafeAreaView,
    FlatList,
    TouchableOpacity,
    Image,
    Alert,
    Modal,
    TouchableHighlight,
    ActivityIndicator
} from "react-native";
import {theme} from "../core/theme";
import {Ionicons} from "@expo/vector-icons";
import ProgressBar from "../components/ProgressBar";
import ButtonsContainer from "../components/ButtonsContainer";
import {ActionSheetProvider, connectActionSheet, useActionSheet} from "@expo/react-native-action-sheet";
import * as ImagePicker from "expo-image-picker";
import Inspection from "../../Services/Inspection";
import mime from "mime";
import TextInput from "../components/TextInput";
import Button from "../components/Button";
import SlideText from "../components/SlideText";

function picturesReducer(state, newItem) {
    if(newItem.action && newItem.action==='remove') {
        return state.filter((item, index) => index !== newItem.index);
    }

    const index = state.findIndex(item => item.uri === newItem.uri);

    if(index >= 0) {
        const update = [...state];
        update[index].uri = newItem.uri;
        return update;
    }

    return [...state, newItem];
}


const CustomView = ({pictures, setPictures, setItem, loading}) => {
    const { showActionSheetWithOptions } = useActionSheet();

    const onOpenActionSheet = () => {
        const options = ['Take a photo', 'Choose a photo', 'Cancel'];
        const destructiveButtonIndex = 2;
        const cancelButtonIndex = 2;

        showActionSheetWithOptions(
            {
                title: 'Select an image',
                options,
                cancelButtonIndex,
                destructiveButtonIndex,
                showSeparators: true,
                useModal: true,
                titleTextStyle: {fontWeight: 'bold', alignSelf: 'center', fontSize: 20}
            },
            buttonIndex => {
                if(buttonIndex == 0) { openCamera().then(r => console.log('Camera')) }
                if(buttonIndex == 1) { pickImage().then(r => console.log(r)) }
            },
        );
    };

    async function pickImage  () {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if(status === 'granted') {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All,
                quality: 0.5,
                noData: true,
            });
            if (!result.cancelled) {
                console.log('Pick Image')
                setItem(result)
            }
        }
    };

    async function openCamera () {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();

        if ( status === 'granted' ) {
            ImagePicker.launchCameraAsync({
                mediaTypes:ImagePicker.MediaTypeOptions.Images,
                quality: 0.5,
                noData: true,
            }).then(r => {
                if(!r.cancelled) {
                    console.log('Result', r)
                    setItem(r)
                }
            })
        }
    };

    function handleImage(index) {
        setPictures({action: 'remove', index: index})
    }

    return (
        <View style={{paddingTop: 15, flexDirection: "column", alignItems: 'center', justifyContent: "space-between"}}>
            <View style={{height: '60%'}}>
                <FlatList
                    data={pictures}
                    renderItem={({item, index}) => (
                        <TouchableOpacity>
                            <View
                                style={{
                                    flexDirection: 'column',
                                    margin: 1
                                }}>
                                <Image
                                    style={styles.imageThumbnail}
                                    source={{uri: item.uri}}
                                />
                            </View>
                        </TouchableOpacity>
                    )}
                    //Setting the number of column
                    numColumns={3}
                    keyExtractor={(item, index) => index}
                />
                {
                    loading &&
                    <ActivityIndicator size="large" color="#0000ff"/>
                }
            </View>
            <View style={{alignItems: 'center'}}>
                <TouchableOpacity onPress={onOpenActionSheet}>
                    <Ionicons name="camera" size={70} color={theme.colors.primary} />
                </TouchableOpacity>
            </View>
        </View>
    )
}

const InspectionGatePictures2 = ({ route, navigation }) => {
    const { inspection } = route.params;
    const [pictures, setPictures] = useReducer(picturesReducer, []);
    const [allPictures, setAllPictures] = useState([]);
    const [loading, setLoading] = useState(true);
    const [modalVisible, setModalVisible] = useState(false);
    const [imageName, setImageName] = useState('');
    const [imgDescription, setImgDescription] = useState('');
    const [selectedImage, setSelectedImage] = useState(null);

    React.useEffect(() => {
        Inspection.get(inspection.id, function (response) {
            setLoading(false);
            setAllPictures(response.pictures);
        });
    }, [])

    const next = () => {
        navigation.navigate('InspectionGateSign', {inspection: inspection});
    }

    const back = () => {
        navigation.navigate('InspectionGatePictures', {inspection: inspection});
    }

    const submitModal = () => {
        const obj = selectedImage
        const newImageUri =  "file:///" + (obj.uri || obj.url).split("file:/").join("");
        const photo = {
            uri: newImageUri,
            type: mime.getType(newImageUri),
            name: newImageUri.split("/").pop(),
            image_name: imageName,
            description: imgDescription,
            column: 'picture',
        }
        setModalVisible(false);
        uploadImage(photo);
    }

    function setItem(obj)
    {
        setSelectedImage(obj);
        setImageName('');
        setImgDescription('');
        setModalVisible(true);
    }

    function uploadImage(photo) {
        setLoading(true);
        Inspection.add_pictures(inspection, photo, function (response) {
            setLoading(false);
            setPictures(photo);
        }, function (error) {
            setLoading(false);
            console.log("Error saving pictures", error)
            Alert.alert("Something went wrong saving the images. Please try again.")
        })
    }

    return (
        <ActionSheetProvider>
            <SafeAreaView style={styles.container}>
                <View style={{flex:1}}>
                    <View style={{flex:1, padding: 8}}>
                        <ProgressBar step={(Math.ceil(inspection.items.length/12) + 2)} inspection={inspection}></ProgressBar>
                        <Text style={{fontSize:18, fontWeight: 'bold', textAlign: 'center'}}>Additional Pictures</Text>
                    </View>
                    <CustomView pictures={allPictures.concat(pictures)} setPictures={setPictures} setItem={setItem} loading={loading}></CustomView>
                </View>
                <ButtonsContainer navigation={navigation} inspection={inspection} onNext={next} loading={loading} onBack={back}></ButtonsContainer>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={modalVisible}
                >
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <View style={{width: '100%', flexDirection: 'row-reverse', marginBottom: 10}}>
                                <TouchableHighlight
                                    onPress={() => {
                                        setModalVisible(!modalVisible);
                                    }}>
                                    <Ionicons name="close" size={25} color={theme.colors.primary} />
                                </TouchableHighlight>
                            </View>
                            <View>
                                <TextInput
                                    label="Image Name"
                                    returnKeyType="next"
                                    value={imageName}
                                    onChangeText={(text) => setImageName(text)}
                                    autoCapitalize="none"
                                />
                                <TextInput
                                    label="Image Description"
                                    returnKeyType="next"
                                    value={imgDescription}
                                    onChangeText={(text) => setImgDescription(text)}
                                    autoCapitalize="none"
                                />
                                <Button mode="contained"
                                        style={{height: 55, justifyContent: 'center'}}
                                        onPress={submitModal}
                                        uppercase={false}
                                >
                                    Submit
                                </Button>
                            </View>
                        </View>
                    </View>
                </Modal>
                <SlideText inspection={inspection} navigation={navigation}/>
            </SafeAreaView>
        </ActionSheetProvider>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    item: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        padding: 0,
        marginVertical: 1,
        borderWidth: 2,
        borderColor: theme.colors.lightgrayb,
        borderTopWidth: 0,
        backgroundColor: '#f5f3f3'
    },
    title: {
        paddingLeft: 8,
        width: '60%'
    },
    imageThumbnail: {
        justifyContent: 'center',
        alignItems: 'center',
        height: 100,
        width: 100
    },
    centeredView: {
        flex: 1,
        marginTop: 22,
    },
    modalView: {
        margin: 20,
        backgroundColor: 'white',
        padding: 35,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
})

export default connectActionSheet(InspectionGatePictures2)