import React, { useState, useCallback } from 'react'
import { TouchableOpacity, StyleSheet, View, CheckBox } from 'react-native'
import { Text } from 'react-native-paper'
import Background from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Button from '../components/Button'
import TextInput from '../components/TextInput'
import { theme } from '../core/theme'
import { emailValidator } from '../helpers/emailValidator'
import { passwordValidator } from '../helpers/passwordValidator'
import Auth from "../../Services/Auth";
import DataManager from "../../DataManager";

function LoginScreen({ navigation }) {
    const [email, setEmail] = useState({ value: '', error: '' })
    const [password, setPassword] = useState({ value: '', error: '' })
    const [buttonLabel, setButtonLabel] = useState('Login')
    const [isSelected, setSelection] = useState(false);
    const [mounted, setMounted] = useState(false);

    React.useEffect(
        React.useCallback(() => {
            if (!mounted) {
                setMounted(true)

                DataManager.shared().getAccessToken(function (res) {
                    if (res) {
                        DataManager.shared().getUserObject(function (user) {
                            if (user) {
                                navigation.reset({
                                    index: 0,
                                    routes: [{ name: 'DrawerNavigation' }],
                                })
                            }
                        })
                    }
                })
            }
        }, [])
        , [])


    /**
     * Each callback should return object that contains success and/or error.
     * @param {Object} data
     * @returns {{ success: Boolean, error: String }}
     */
    const submitAuth = async (data, route) => {
        setButtonLabel('Loading...');
        const emailError = emailValidator(email.value)
        const passwordError = passwordValidator(password.value)

        if (emailError || passwordError) {
            setEmail({ ...email, error: emailError })
            setPassword({ ...password, error: passwordError })
            setButtonLabel('Login');
            return
        }

        await Auth.login(email.value, password.value, function (response) {
            navigation.reset({
                index: 0,
                routes: [{ name: route }],
            })
        }, function (error) {
            setButtonLabel('Login');
        });

    };

    const onLoginPressed = async (data) => await submitAuth(data, 'DrawerNavigation');

    return (
        <Background>
            <View style={{ height: 74 }}></View>
            <Logo />
            <Header></Header>
            <Text style={styles.title}>Log in to your account</Text>
            <TextInput
                label="Email"
                returnKeyType="next"
                value={email.value}
                onChangeText={(text) => setEmail({ value: text, error: '' })}
                error={!!email.error}
                errorText={email.error}
                autoCapitalize="none"
                autoCompleteType="email"
                textContentType="emailAddress"
                keyboardType="email-address"
            />
            <TextInput
                label="Password"
                returnKeyType="done"
                value={password.value}
                onChangeText={(text) => setPassword({ value: text, error: '' })}
                error={!!password.error}
                errorText={password.error}
                secureTextEntry
            />
            <View style={styles.keepMeSigned}>
                <CheckBox
                    value={isSelected}
                    onValueChange={setSelection}
                    style={styles.checkbox}
                />
                <Text style={{ color: theme.colors.gray, marginLeft: 4 }}>Keep me signed in</Text>
            </View>
            <Button mode="contained"
                onPress={onLoginPressed}
                disabled={buttonLabel != 'Login' ? true : false}>
                {buttonLabel}
            </Button>
            <View style={styles.row}>
                <TouchableOpacity
                    onPress={() => navigation.navigate('ForgotPasswordScreen')}
                >
                    <Text style={styles.link}>Forgot your password?</Text>
                </TouchableOpacity>
            </View>
        </Background>
    )
}

const styles = StyleSheet.create({
    title: {
        width: '100%',
        fontWeight: 'bold',
        fontSize: 16,
        color: theme.colors.gray
    },
    keepMeSigned: {
        width: '100%',
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "flex-start",
        marginBottom: 24,
    },
    forgotPassword: {
        width: '100%',
        alignItems: 'flex-end',
        marginBottom: 24,
    },
    row: {
        flexDirection: 'row',
        marginTop: 4,
    },
    forgot: {
        fontSize: 13,
        color: theme.colors.secondary,
    },
    link: {
        fontWeight: 'bold',
        color: theme.colors.primary,
    },
    checkbox: {
        alignSelf: "center",
    },
})

export default LoginScreen
