import React, { useState } from 'react'
import {
    StyleSheet,
    View,
    Text,
    SafeAreaView,
    TouchableOpacity,
    Alert, ScrollView, KeyboardAvoidingView
} from "react-native";
import {theme} from "../core/theme";
import ProgressBar from "../components/ProgressBar";
import SignatureScreen from 'react-native-signature-canvas';
import Inspection from "../../Services/Inspection";
import Button from "../components/Button";
import {Ionicons} from "@expo/vector-icons";
import SlideText from "../components/SlideText";
import TextInput from "../components/TextInput";
import DataManager from "../../DataManager";

const InspectionGateSign = ({ route, navigation }) => {
    const driverSignatureRef = React.useRef(null);
    const receiverSignatureRef = React.useRef(null);
    const [driverSignature, setDriverSignature] = useState('');
    const [receiverSignature, setReceiverSignature] = useState('');
    const [loading, setLoading] = useState(false);
    const [driverName, setDriverName] = useState('');
    const [contactName, setContactName] = useState('');
    const [enableScrollViewScroll, setEnableScrollViewScroll] = useState(true);

    const { inspection } = route.params

    React.useEffect(
        React.useCallback(() => {
            DataManager.shared().getAccessToken(function (res) {
                if (res) {
                    DataManager.shared().getUserObject(function (user) {
                        if (user) {
                            setDriverName(user.name);
                        }
                    })
                }
            })
        }, [])
        , [])

    async function next() {
        inspection.driver_signature = driverSignature;
        inspection.receiver_signature = receiverSignature;
        inspection.driver_name = driverName;
        inspection.receiver_name = contactName;
        setLoading(true);

        await Inspection.update(inspection, [], function (response) {
            setLoading(false);
            navigation.navigate('Success', {inspection: inspection});
        }, function (error) {
            setLoading(false);
            console.log("Error saving signs", error);
            Alert.alert("Something went wrong. Please try again.");
        });
    }

    const handleDriverEnd = () => {
        driverSignatureRef.current.readSignature();
        setEnableScrollViewScroll(true);
    };

    const handleReceiverEnd = () => {
        receiverSignatureRef.current.readSignature();
        setEnableScrollViewScroll(true);
    };

    const handleDriverOK = (signature) => {
        setDriverSignature(signature);
    };

    const handleRecOK = (signature) => {
        setReceiverSignature(signature);
    };

    const handleOnBegin = () => {
        setEnableScrollViewScroll(false);
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={{flex:1}}>
                <View style={{flex:1, padding: 8}}>
                    <ProgressBar step={Math.ceil(inspection.items.length/12)+3} inspection={inspection}></ProgressBar>
                    <ScrollView
                        nestedScrollEnabled={true}
                        scrollEnabled={enableScrollViewScroll}
                    >
                        <View style={{paddingLeft:5, paddingRight:5, flexDirection: "column", height: '100%'}}>
                        <KeyboardAvoidingView behavior="padding" style={{flex: 1}}>
                            <View style={styles.date}>
                                <Text style={styles.subTitle}>{inspection.inspection_type} Contact</Text>
                                <TouchableOpacity onPress={() => {
                                    receiverSignatureRef.current.clearSignature();
                                }}>
                                    <Text style={styles.clearOption}>Clear</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={{height: 110}}>
                                <SignatureScreen
                                    ref={receiverSignatureRef}
                                    onOK={handleRecOK}
                                    onBegin={handleOnBegin}
                                    onEnd={handleReceiverEnd}
                                />
                            </View>
                            <View style={styles.date}>
                                <TextInput
                                    label="Contact Name"
                                    returnKeyType="next"
                                    value={contactName}
                                    onChangeText={(text) => setContactName(text)}
                                    autoCapitalize="none"
                                />
                            </View>
                            <View style={{marginTop: 15}}>
                                <View style={styles.date}>
                                    <Text style={styles.subTitle}>CLR Driver</Text>
                                    <TouchableOpacity onPress={() => {
                                        driverSignatureRef.current.clearSignature();
                                    }}>
                                        <Text style={styles.clearOption}>Clear</Text>
                                    </TouchableOpacity>
                                </View>
                                <View style={{height: 110}}>
                                    <SignatureScreen
                                        ref={driverSignatureRef}
                                        onOK={handleDriverOK}
                                        onBegin={handleOnBegin}
                                        onEnd={handleDriverEnd}
                                    />
                                </View>
                                <View style={styles.date}>
                                    <TextInput
                                        label="Driver Name"
                                        returnKeyType="next"
                                        value={driverName}
                                        onChangeText={(text) => setDriverName(text)}
                                        autoCapitalize="none"
                                    />
                                </View>
                            </View>
                        </KeyboardAvoidingView>
                    </View>
                    </ScrollView>
                </View>
            </View>
            <View style={styles.buttonContainerP}>
                <View style={styles.buttonContainer}>
                    <Button mode="outlined"
                            style={styles.outlineButton}
                            onPress={() => navigation.goBack()}
                            uppercase={false}
                            icon={() => <Ionicons name="arrow-back" size={25} color={theme.colors.primary}/>}
                    >
                        Back
                    </Button>
                </View>
                <View style={styles.buttonContainer}>
                    <Button mode="contained"
                            uppercase={false}
                            style={styles.finishButton}
                            onPress={() => next()}
                            contentStyle={{flexDirection: 'row-reverse'}}
                            disabled={driverSignature==='' || receiverSignature==='' || loading}
                    >
                        Finish
                    </Button>
                </View>
            </View>
            <SlideText inspection={inspection} navigation={navigation}/>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    buttonContainerP: {
        flexDirection: "row",
        alignItems:'center',
        justifyContent:'space-between',
        padding: 0,
        backgroundColor: 'white'
    },
    buttonContainer: {
        flex:0.5,
        paddingLeft: 10,
        paddingRight: 10
    },
    outlineButton: {
        height: 65,
        justifyContent: 'center',
        borderRadius: 5, borderWidth: 2,
        borderColor:
        theme.colors.primary
    },
    item: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        padding: 0,
        marginVertical: 1,
        borderWidth: 2,
        borderColor: theme.colors.lightgrayb,
        borderTopWidth: 0,
        backgroundColor: '#f5f3f3'
    },
    title: {
        paddingLeft: 8,
        width: '60%'
    },
    subTitle: {
        fontSize:18,
        fontWeight: 'bold',
        paddingBottom: 5
    },
    scrollContainer: {
        flex: 1
    },
    signature: {
        borderWidth:1,
        height: '100%',
    },
    date: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
    },
    clearOption: {
        fontWeight: 'bold'
    },
    finishButton: {
        height: 65,
        justifyContent: 'center',
        borderRadius: 5
    }
})

export default InspectionGateSign
