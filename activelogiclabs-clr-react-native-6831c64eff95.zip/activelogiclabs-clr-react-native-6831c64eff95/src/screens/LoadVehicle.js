import React, { useState } from 'react'
import {
    StyleSheet,
    View,
    Text,
    SafeAreaView,
    TouchableOpacity,
    ActivityIndicator,
    TouchableHighlight,
    Modal,
    ScrollView
} from "react-native";
import { theme } from "../core/theme";
import { Ionicons } from "@expo/vector-icons";
import Button from "../components/Button";
import Vehicle from "../../Services/Vehicle";
import { Alert } from "react-native";
import * as Location from "expo-location";
import TextInput from "../components/TextInput";

const LoadVehicle = ({ route, navigation }) => {
    let { vin } = route.params
    const [inspection, setInspection] = useState({})
    const [inspectionType, setInspectionType] = useState(null)
    const [vehicle, setVehicle] = useState(null)
    const [workOrder, setWorkOrder] = useState({})
    const [started, setStarted] = useState(false)
    const [location, setLocation] = React.useState(null);
    const [dataButtons, setDataButtons] = React.useState([]);
    const [status, setStatus] = React.useState('')
    const [enabledButtons, setEnabledButtons] = React.useState([2, 3, 4])
    const [statusDisabled, setStatusDisabled] = React.useState(false)
    const [modalVisible, setModalVisible] = useState(false)
    const [shopName, setShopName] = useState('')
    const [selectedButton, setSelectedButton] = useState('')
    const [detaching, setDetaching] = useState(false)

    React.useEffect(() => {
        (async () => {
            let isSubscribed = true
            const unsubscribe = navigation.addListener('focus', () => {
                setStarted(false);

                if (vin) {
                    Vehicle.getByVin(vin, function (response) {
                        if (isSubscribed) {
                            setVehicle(response.vehicle)
                            setWorkOrder(response.workOrder)
                            setShopName(response.vehicle.shop_name)
                            if (response.workOrder.status.title === 'Delivered') {
                                Alert.alert("This vehicle has been delivered. Please select another vehicle")
                                navigation.navigate('Dashboard')
                                return;
                            } else {

                                Location.getBackgroundPermissionsAsync().then((statusPerm) => {
                                    if (statusPerm.status === 'granted') {
                                        try {
                                            Location.getCurrentPositionAsync({}).then((locationRes) => {
                                                if (isSubscribed) {
                                                    setLocation(locationRes);
                                                    Vehicle.setLocation(vin, locationRes)
                                                }
                                            });
                                        } catch (e) {
                                            console.log('LocationError: ', e.message)
                                        }
                                    }
                                });

                                let inspection_obj = {
                                    id: null,
                                    vehicle_id: response.vehicle.id,
                                    vehicle_vin: response.vehicle.vin,
                                    vehicle_make: response.vehicle.make.title,
                                    customer_id: response.workOrder.customer_id,
                                    yard_id: response.vehicle.yard_id,
                                    inspection_type_id: response.inspection_type ? response.inspection_type.id : null,
                                    inspection_type: response.inspection_type ? response.inspection_type.title : null,
                                    inspection_type_order: response.inspection_type ? response.inspection_type.display_order : null,
                                    items: response.items,
                                    item_inputs: [],
                                    photo_driver_url: null,
                                    photo_passenger_url: null,
                                    photo_front_url: null,
                                    photo_back_url: null,
                                    driver_signature: null,
                                    driver_name: '',
                                    receiver_signature: null,
                                    receiver_name: '',
                                    finish: null,
                                    pictures: [],
                                    work_order_id: response.workOrder.id
                                };

                                if (response.inspection) {
                                    inspection_obj.id = response.inspection.id
                                    inspection_obj.item_inputs = response.inspection.item_inputs
                                    inspection_obj.photo_driver_url = response.inspection.photo_driver_url
                                    inspection_obj.photo_passenger_url = response.inspection.photo_passenger_url
                                    inspection_obj.photo_front_url = response.inspection.photo_front_url
                                    inspection_obj.photo_back_url = response.inspection.photo_back_url
                                    inspection_obj.pictures = response.inspection.pictures
                                }

                                setInspection(inspection_obj)
                                setInspectionType(response.inspection_type)

                                if (response.inspection_type && response.inspection_type.display_order > 0) {
                                    const dataB = [
                                        { id: 3, title: 'Picked Up/In Transit', value: 'Picked Up/In Transit', reason: null, shopName: null, enabled: [1, 2, 4] },
                                        { id: 4, title: 'Transport to repair Shop', value: 'to-repair', reason: 'Being Repair', showModal: true, showName: '', enabled: [5] },
                                        { id: 5, title: 'Transport from repair Shop', value: 'from-repair', reason: null, shopName: null, enabled: [1, 2, 3] },
                                    ]
                                    setDataButtons(dataB)
                                    const option = dataB.filter((item) => response.vehicle.status.title === item.title)
                                    const options = response.vehicle.status.title === 'Storage' ? [3, 4] : (option.length > 0 ? option[0].enabled : [2, 3, 4])
                                    setEnabledButtons(options)
                                }
                                setStarted(true)
                                setStatus(response.vehicle.status.title)
                            }
                        }
                    }, function (error) {
                        if (error.hasOwnProperty("error")) {
                            Alert.alert("Something went wrong. \n" + error.error)
                        } else {
                            Alert.alert("Something went wrong, please try again...")
                        }
                        setInterval(() => { }, 100);
                        navigation.navigate('Dashboard')
                    })
                } else {
                    Alert.alert("A vin is required. Please try again...");

                    setInterval(() => { }, 100);

                    navigation.navigate('Dashboard');
                }
            });
            return () => {
                unsubscribe;
                isSubscribed = false;
            };
        })();
    }, [navigation]);

    async function getVehicle(vin, isSubscribed) {

    }

    const changeStatus = (item) => {
        setStatus(item.title);
        setStatusDisabled(true);
        setModalVisible(false);

        if (item.value !== 'to-repair') {
            setShopName(null);
        }

        item.shopName = shopName
        Vehicle.changeStatus(vehicle.id, workOrder.id, item, function (response) {
            setStatusDisabled(false)
            setEnabledButtons(item.enabled)
        }, function () {
            setStatusDisabled(false)
        })

    }

    if (!started) {
        return (<ActivityIndicator size="large" color="#0000ff" style={{ marginTop: '50%' }} />)
    }

    function startInspection(type, goTo) {
        navigation.navigate(goTo, { inspection: inspection })
    }

    function showModal(item) {
        setShopName(null)
        setSelectedButton(item)
        setModalVisible(true)
    }

    function confirmationSetStatus(item) {
        if (item.value === 'Picked Up/In Transit') {
            Alert.alert(
                'Confirmation',
                'Are you sure you want to change the status?',
                [
                    {
                        text: 'No',
                        onPress: () => { return false },
                    },
                    {
                        text: 'Yes',
                        onPress: () => { changeStatus(item) },
                    }
                ],
                { cancelable: false },
            );
        } else {
            item.showModal ? showModal(item) : changeStatus(item)
        }
    }

    function detach(id) {
        setDetaching(true)
        Vehicle.detach(id, (response) => {
            navigation.navigate('Dashboard')
        }, (error) => {
            Alert.alert("Something went wrong. Please try again.")
            setDetaching(false)
        })
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={{ flex: 1 }}>
                <View style={{ flex: 1 }}>
                    <ScrollView>
                        <View>
                            <View style={[styles.padding, { backgroundColor: theme.colors.gradient, opacity: 0.8 }]}>
                                <Text style={styles.description}>VIN: {vin}</Text>
                                <Text style={styles.description}>Make: {vehicle.make.title}</Text>
                                {
                                    status !== '' &&
                                    (<Text style={styles.description}>Status: {status}</Text>)
                                }
                                {
                                    vehicle.yard &&
                                    (<Text style={styles.description}>Yard: {vehicle.yard ? vehicle.yard.name : ''}</Text>)
                                }
                                {
                                    vehicle.yard_bay && vehicle.yard_bay != '' &&
                                    (<Text style={styles.description}>Bay: {vehicle.yard_bay}</Text>)
                                }
                                {
                                    shopName &&
                                    (<Text style={styles.description}>Shop Name: {shopName}</Text>)
                                }
                                {
                                    inspectionType && inspectionType.display_order == 0 &&
                                    (
                                        <View>
                                            <Text style={[styles.description, { fontWeight: 'bold' }]}>PICKUP</Text>
                                            <Text style={styles.description}>  Ready Date: {workOrder.pickup_ready_date}</Text>
                                            <Text style={styles.description}>  Contact: {workOrder.pickup_contact_name}</Text>
                                            <Text style={styles.description}>  Phone: {workOrder.pickup_contact_phone}</Text>
                                            <Text style={styles.description}>  Address: </Text>
                                            <Text style={styles.description}>  {workOrder.pickup_address} {workOrder.pickup_city}. {workOrder.pickup_state}</Text>
                                        </View>
                                    )
                                }
                                {
                                    inspectionType && inspectionType.display_order > 0 &&
                                    (
                                        <View>
                                            <Text style={[styles.description, { fontWeight: 'bold' }]}>DELIVERY</Text>
                                            <Text style={styles.description}>  Ready Date: {workOrder.requested_delivery_date}</Text>
                                            <Text style={styles.description}>  Contact: {workOrder.delivery_contact_name}</Text>
                                            <Text style={styles.description}>  Phone: {workOrder.delivery_contact_phone}</Text>
                                            <Text style={styles.description}>  Address: </Text>
                                            <Text style={styles.description}>  {workOrder.delivery_address} {workOrder.delivery_city}. {workOrder.delivery_state}</Text>
                                        </View>
                                    )
                                }
                            </View>
                            <View style={styles.padding}>
                                {
                                    (
                                        inspectionType && inspectionType.display_order === 0 &&
                                        <View>
                                            <Button mode="contained"
                                                style={{ height: 65, justifyContent: 'center' }}
                                                onPress={() => startInspection(inspectionType.title, 'InspectionGate')}
                                                icon={() => <Ionicons color={'#FFF'} size={20} name={'ios-car-sharp'} />}
                                            >
                                                {inspectionType.title}
                                            </Button>
                                        </View>
                                    )
                                }
                                {
                                    (
                                        inspectionType && inspectionType.display_order > 0 &&
                                        <View>
                                            <View style={{ padding: 10, paddingTop: 0 }}>
                                                <Button mode="contained"
                                                    style={{ height: 65, justifyContent: 'center', alignItems: 'center' }}
                                                    onPress={() => startInspection(inspectionType.title, 'InspectionGate')}
                                                    disabled={statusDisabled || !enabledButtons.includes(1)}
                                                >
                                                    {inspectionType.title}
                                                </Button>
                                                <Button mode="outlined"
                                                    style={styles.outlineButton}
                                                    onPress={() => navigation.navigate('ChangeYard', { vehicle: vehicle })}
                                                    disabled={statusDisabled || !enabledButtons.includes(2)}
                                                >
                                                    Storage
                                                </Button>
                                                {
                                                    dataButtons.length > 0 && dataButtons.map((item, index) =>
                                                        <Button mode="outlined"
                                                            style={styles.outlineButton}
                                                            onPress={() => statusDisabled ? null : confirmationSetStatus(item)}
                                                            disabled={statusDisabled || status === item.title || !enabledButtons.includes(item.id)}
                                                            key={index.toString()}
                                                        >
                                                            {item.title} {statusDisabled && status === item.title && '...'}
                                                        </Button>)
                                                }
                                            </View>
                                        </View>
                                    )
                                }
                                <View>
                                    <Button mode="contained"
                                        style={{ height: 65, justifyContent: 'center' }}
                                        onPress={() => detach(workOrder.id)}
                                        icon={() => <Ionicons color={'#FFF'} size={20} name={'remove'} />}
                                        disabled={detaching}
                                    >
                                        {detaching ? 'Wait...' : 'Detach'}
                                    </Button>
                                </View>
                            </View>
                        </View>
                    </ScrollView>
                </View>
            </View>
            <View style={styles.footer}>
                <TouchableOpacity
                    style={{
                        paddingLeft: 10,
                    }}
                    onPress={() => navigation.navigate('Dashboard', {from: 'LoadVehicle'})}
                >
                    <Ionicons name="arrow-back" size={32} color="white" />
                </TouchableOpacity>
            </View>

            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
            >
                <View style={styles.centeredView}>
                    <View style={styles.modalView}>
                        <View style={{ width: '100%', flexDirection: 'row-reverse', marginBottom: 10 }}>
                            <TouchableHighlight
                                onPress={() => {
                                    setModalVisible(!modalVisible);
                                }}>
                                <Ionicons name="close" size={25} color={theme.colors.primary} />
                            </TouchableHighlight>
                        </View>
                        <View>
                            <Text>Input Shop Name</Text>
                            <TextInput
                                label="Shop Name"
                                returnKeyType="next"
                                value={shopName}
                                onChangeText={(text) => setShopName(text)}
                                autoCapitalize="none"
                            />
                            <Button mode="contained"
                                style={{ height: 55, justifyContent: 'center' }}
                                onPress={() => changeStatus(selectedButton)}
                            >
                                Submit
                            </Button>
                        </View>
                    </View>
                </View>
            </Modal>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF',
        height: '100%'
    },
    padding: {
        padding: 10
    },
    fontSize: {
        fontSize: 16
    },
    description: {
        fontSize: 18,
        color: theme.colors.textWhite
    },
    item: {
        backgroundColor: theme.colors.lightgray,
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        padding: 0,
        marginVertical: 1,
        marginLeft: 0,
        borderLeftWidth: 5,
        borderLeftColor: theme.colors.gray,
    },
    title: {
        paddingLeft: 8,
        width: '30%'
    },
    footer: {
        backgroundColor: theme.colors.primary,
        height: 65,
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        bottom: 0,
    },
    footerText: {
        color: '#FFF',
        fontSize: 16
    },
    buttonContainer: {
        flex: 0.5,
        padding: 10
    },
    centerRow: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between"
    },
    outlineButton: {
        height: 65,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: theme.colors.primary
    },
    centeredView: {
        flex: 1,
        marginTop: 22,
    },
    modalView: {
        margin: 20,
        backgroundColor: 'white',
        padding: 35,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
})

export default LoadVehicle
