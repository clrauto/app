import React from 'react';
import Background from '../components/Background';
import Button from '../components/Button';
import {StyleSheet, View, Text} from "react-native";
import {Ionicons} from "@expo/vector-icons";
import {theme} from "../core/theme";
import SlideText from "../components/SlideText";

const Success = ({ route, navigation }) => {
    const { inspection } = route.params;

    function goHome() {
        if (inspection.inspection_type_order === 0) {
            navigation.navigate('LoadVehicle', {vin: inspection.vehicle_vin});
        } else {
            navigation.navigate('Dashboard');
        }
    }

    return (<Background>
        <View style={{flex: 1, padding: 20, flexDirection:"column", alignItems: 'center', justifyContent:'space-between'}}>
            <View style={{ alignItems: 'center', marginTop: 20}}>
                <Text style={{fontSize: 20, fontWeight: 'bold', color: theme.colors.gradient2}}>Success!</Text>
                <Ionicons name="checkmark-circle" size={200} color={theme.colors.gradient2} />
                <Text>This vehicle has been {inspection.inspection_type}.</Text>
            </View>
            <View style={{alignItems: 'center'}}>
                <SlideText inspection={inspection} navigation={navigation} button={true}/>
                <Button
                    mode="outlined"
                    style={styles.homeButton}
                    onPress={() => goHome()}
                    icon={() => <Ionicons name="home-sharp" size={25} color={theme.colors.primary} />}
                    uppercase={false}
                >
                    Continue
                </Button>
            </View>
        </View>
    </Background>)
}
const styles = StyleSheet.create({
    homeButton: {
        height: 55,
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: theme.colors.primary,
        paddingLeft: 20,
        paddingRight: 20
    }
})

export default Success
