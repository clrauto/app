import React, { useState } from 'react'
import {
    StyleSheet,
    FlatList,
    View,
    Text,
    SafeAreaView,
    Alert,
    TouchableOpacity,
    ActivityIndicator,
    TouchableHighlight, Modal
} from "react-native";
import {theme} from "../core/theme";
import Inspection from "../../Services/Inspection";
import DataManager from "../../DataManager";
import {Ionicons} from "@expo/vector-icons";
import Vehicle from "../../Services/Vehicle";
import TextInput from "../components/TextInput";
import Button from "../components/Button";

const ChangeYard = ({ route, navigation }) => {

    let { vehicle } = route.params ? route.params : []
    const [started, setStarted] = useState(false)
    const [data, setData] = useState([])
    const [modalVisible, setModalVisible] = useState(false)
    const [yardBay, setYardBay] = useState(vehicle ? vehicle.yard_bay : '')
    const [selectedItem, setSelectedItem] = useState(null)

    const renderItem = ({ item }) => <TouchableOpacity style={styles.item} key={`item-${item.id}`}
                                                       onPress={() => showModal(item)}>
                                        <Text style={[styles.title]}>{item.name}</Text>
                                        {vehicle && vehicle.yard_id == item.id && (<Ionicons name="checkmark" size={25} color={theme.colors.primary} />)}
                                    </TouchableOpacity>;

    React.useEffect(() => {
        Inspection.getYards(function (response) {
            setData(response.yards);
            setStarted(true)
        }, function (error) {
            Alert.alert("Something went wrong, please try again.")
            navigation.goBack();
        })
    }, [])

    async function submitYard() {
        const yard = selectedItem
        setStarted(false)
        await Vehicle.setYard(vehicle.id, {yard_id: yard.id, yard_bay: yardBay},function (response) {
            setStarted(true)
            setModalVisible(false)
            DataManager.shared().setYard(
                yard, function(){}
            );
            setInterval(() => {}, 100);
            navigation.goBack()
        }, function (error) {
            setStarted(true)
            setModalVisible(false)
            Alert.alert("Something went wrong, please try again.")
        })
    }

    function showModal(item)
    {
        setYardBay(null);
        setSelectedItem(item);
        setModalVisible(true)
    }

    if(!started) {
        return (
            <ActivityIndicator size="large" color="#0000ff" style={{marginTop: '50%'}}/>
        )
    }

    return (
            <SafeAreaView style={styles.container}>
                <FlatList
                    data={data}
                    renderItem={renderItem}
                    ItemSeparatorComponent={
                        ({ highlighted }) => <View style={[styles.separator, { marginLeft: 0 }]} />
                    }
                    keyExtractor={item => `key-${item.id}`} />
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={modalVisible}
                >
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <View style={{width: '100%', flexDirection: 'row-reverse', marginBottom: 10}}>
                                <TouchableHighlight
                                    onPress={() => {
                                        setModalVisible(!modalVisible);
                                    }}>
                                    <Ionicons name="close" size={25} color={theme.colors.primary} />
                                </TouchableHighlight>
                            </View>
                            <View>
                                <Text>Input Bay (Optional)</Text>
                                <TextInput
                                    label="Bay"
                                    returnKeyType="next"
                                    value={yardBay}
                                    onChangeText={(text) => setYardBay(text)}
                                    autoCapitalize="none"
                                />
                                <Button mode="contained"
                                        style={{height: 55, justifyContent: 'center'}}
                                        onPress={() => vehicle ? submitYard() : console.log('submit yard')}
                                        uppercase={false}
                                >
                                    Submit
                                </Button>
                            </View>
                        </View>
                    </View>
                </Modal>
            </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    item: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "flex-start",
        padding: 10,
        marginVertical: 6,
        marginHorizontal: 10,
    },
    title: {
        fontSize: 16,
        paddingRight: 20
    },
    separator: {
        height:  1,
        backgroundColor: theme.colors.lightgrayb
    },
    centeredView: {
        flex: 1,
        marginTop: 22,
    },
    modalView: {
        margin: 20,
        backgroundColor: 'white',
        padding: 35,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
})

export default ChangeYard
