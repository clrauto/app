import React, {useReducer, useState} from 'react'
import {ActionSheetProvider, connectActionSheet, useActionSheet} from '@expo/react-native-action-sheet'
import {
    StyleSheet,
    View,
    Text,
    SafeAreaView,
    TouchableOpacity,
    Image,
    Alert,
    ScrollView,
    ActivityIndicator
} from "react-native";
import {theme} from "../core/theme";
import {Ionicons} from "@expo/vector-icons";
import ProgressBar from "../components/ProgressBar";
import ButtonsContainer from "../components/ButtonsContainer";
import * as ImagePicker from "expo-image-picker";
import Inspection from "../../Services/Inspection";
import mime from "mime";
import SlideText from "../components/SlideText";

function infoSideReducer(state, newItem) {
    const index = state.findIndex(item => item.side === newItem.side);
    if(index >= 0) {
        const update = [...state];
        update[index].value = update[index].uri = newItem.uri;
        return update;
    }
    return [...state, newItem];
}

const CustomView = ({infoSide, setInfoSide, inspection, setLoading, checked}) => {
    const { showActionSheetWithOptions } = useActionSheet();
    const [ loadingImage, setLoadingImage ] = useState({side: '', loading: false});

    function onOpenActionSheet(side) {
        const options = ['Take a photo', 'Choose a photo', 'Cancel'];
        const destructiveButtonIndex = 2;
        const cancelButtonIndex = 2;

        showActionSheetWithOptions(
            {
                title: 'Select an image',
                options,
                cancelButtonIndex,
                destructiveButtonIndex,
                showSeparators: true,
                useModal: true,
                titleTextStyle: {fontWeight: 'bold', alignSelf: 'center', fontSize: 20}
            },
            buttonIndex => {
                if(buttonIndex == 0) { openCamera(side).then(r => console.log('Camera', r))}
                if(buttonIndex == 1) { pickImage(side).then(r => console.log(r)) }
            },
        );
    };

    async function pickImage  (side) {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

        if(status === 'granted') {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                quality: 0.5,
                noData: true,
            });

            if (!result.cancelled) {
                setInspectionImages(side, result)
            }
        }
    };

    async function openCamera  (side) {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();

        if(status === 'granted') {
            ImagePicker.launchCameraAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                quality: 0.5,
                noData: true,
            }).then(r => {
                if(!r.cancelled) {
                    setInspectionImages(side, r)
                }
            })
        }
    };

    function setInspectionImages(side, object) {
        const newImageUri =  "file:///" + (object.uri || object.url).split("file:/").join("");
        const photo = {
            uri: newImageUri,
            type: mime.getType(newImageUri),
            name:  side + '-image-' + inspection.id,
            side: side,
            column: `photo_${side}_side_file_name`,
        }

        uploadImage(photo);
    }

    function selectedSide(side) {
        const index = infoSide.findIndex(item => item.side === side);

        if(index >= 0) {
            return infoSide[index].uri;
        }

        return null;
    }

    function uploadImage(photo)
    {
        setLoading(true);
        setLoadingImage({side: photo.side, loading: true});

        Inspection.uploadPhoto(inspection, photo, function (response) {
            inspection.photo_driver_url = response.photo_driver_url;
            inspection.photo_passenger_url = response.photo_passenger_url;
            inspection.photo_front_url = response.photo_front_url;
            inspection.photo_back_url = response.photo_back_url;
            setInfoSide(photo);
            setLoading(false);
            setLoadingImage({side: '', loading: false});
        }, function (error) {

            setLoading(false);
            setLoadingImage({side: '', loading: false});
            console.log("Error saving pictures", error)
            Alert.alert("Something went wrong saving the image. Please try again.")
        })
    }

    return (
        <View>
            <View style={styles.iconsContainer}>
                <TouchableOpacity
                    style={[
                            styles.iconButton,
                            (!inspection.photo_driver_url && checked)
                                ? styles.highlightedItem
                                : ''
                            ]}
                    onPress={() => onOpenActionSheet('driver')}
                >
                    {
                        loadingImage.side === 'driver' &&
                        <ActivityIndicator size="large" color="#0000ff"/>
                    }
                    {
                        ( inspection.photo_driver_url && (loadingImage.side != 'driver')) &&
                        <Image source={{ uri: inspection.photo_driver_url }} style={{ width: '90%', height: '90%' }} />
                    }
                    {
                        !inspection.photo_driver_url &&
                        <Ionicons name="md-person" size={90} color={theme.colors.primary} />
                    }
                    <Text>Driver Side</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[
                        styles.iconButton,
                        (!inspection.photo_passenger_url && checked)
                            ? styles.highlightedItem
                            : ''
                    ]}
                    onPress={() => onOpenActionSheet('passenger')}
                >
                    {
                        loadingImage.side === 'passenger' &&
                        <ActivityIndicator size="large" color="#0000ff"/>
                    }
                    {
                        (inspection.photo_passenger_url && (loadingImage.side != 'passenger')) &&
                        <Image source={{ uri: inspection.photo_passenger_url }} style={{ width: '90%', height: '90%' }} />
                    }
                    {
                        !inspection.photo_passenger_url &&
                        <Ionicons name="md-people" size={80} color={theme.colors.primary} />
                    }
                    <Text>Passenger Side</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.iconsContainer}>
                <TouchableOpacity
                    style={[
                        styles.iconButton,
                        (!inspection.photo_front_url && checked)
                            ? styles.highlightedItem
                            : ''
                    ]}
                    onPress={() => onOpenActionSheet('front')}
                >
                    {
                        loadingImage.side === 'front' &&
                        <ActivityIndicator size="large" color="#0000ff"/>
                    }
                    {
                        (inspection.photo_front_url && (loadingImage.side != 'front')) &&
                        <Image source={{ uri: inspection.photo_front_url }} style={{ width: '90%', height: '90%' }} />
                    }
                    {
                        !inspection.photo_front_url &&
                        <Ionicons name="md-car" size={100} color={theme.colors.primary} />
                    }
                    <Text>Front Side</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[
                        styles.iconButton,
                        (!inspection.photo_back_url && checked)
                            ? styles.highlightedItem
                            : ''
                    ]}
                    onPress={() => onOpenActionSheet('back')}
                >
                    {
                        loadingImage.side === 'back' &&
                        <ActivityIndicator size="large" color="#0000ff"/>
                    }
                    {
                        (inspection.photo_back_url && (loadingImage.side != 'back')) &&
                        <Image source={{ uri: inspection.photo_back_url }} style={{ width: '90%', height: '90%' }} />
                    }
                    {
                        !inspection.photo_back_url &&
                        <Ionicons name="md-car-outline" size={100} color={theme.colors.primary} />
                    }
                    <Text>Back Side</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const InspectionGatePictures = ({ route, navigation }) => {
    const { inspection } = route.params
    const [infoSide, setInfoSide] = useReducer(infoSideReducer, [])
    const [loading, setLoading] = useState(false);
    const [checked, setChecked] = useState(false);

    const next = () => {
        if (!inspection.photo_driver_url
            || !inspection.photo_passenger_url
            || !inspection.photo_front_url
            || !inspection.photo_back_url) {
            Alert.alert("All photos are required.");
            setChecked(true);
        } else {
            navigation.navigate('InspectionGatePictures2', {inspection: inspection});
        }
    }

    const back = () => {
        navigation.navigate('InspectionGate', {inspection: inspection});
    }

    return (
        <ActionSheetProvider>
            <SafeAreaView style={styles.container}>
                <View style={{flex:1}}>
                    <View style={{flex:1, padding: 8}}>
                        <ProgressBar step={Math.ceil(inspection.items.length/12)+1} inspection={inspection}></ProgressBar>
                        <Text style={{fontSize:18, fontWeight: 'bold', textAlign: 'center'}}>Take pictures of all vehicle sides</Text>
                        <ScrollView style={{height: '100%'}}>
                            <CustomView infoSide={infoSide}
                                        setInfoSide={setInfoSide}
                                        inspection={inspection}
                                        setLoading={setLoading}
                                        checked={checked}
                            >
                            </CustomView>
                        </ScrollView>
                    </View>
                </View>
                <ButtonsContainer
                    next={'InspectionGatePictures2'}
                    navigation={navigation}
                    inspection={inspection}
                    onNext={next}
                    loading={loading}
                    onBack={back}
                >
                </ButtonsContainer>
                <SlideText inspection={inspection} navigation={navigation}/>
            </SafeAreaView>
        </ActionSheetProvider>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    buttonContainer: {
        flex:0.5,
        padding: 10
    },
    item: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        padding: 0,
        marginVertical: 1,
        borderWidth: 2,
        borderColor: theme.colors.lightgrayb,
        borderTopWidth: 0,
        backgroundColor: '#f5f3f3'
    },
    title: {
        paddingLeft: 8,
        width: '60%'
    },
    iconsContainer: {
        height: '50%',
        flexDirection: "row",
        alignItems: 'center',
        justifyContent:'center',
        padding: 15,
        paddingBottom: 0
    },
    iconButton: {
        height: '95%',
        minHeight: 160,
        width: '45%',
        margin: 15, padding: 15,
        alignItems: 'center',
        borderWidth: 3,
        borderColor: theme.colors.lightgrayb,
        borderRadius: 12
    },
    iconButtonError: {
        borderColor: theme.colors.error,
    },
    highlightedItem: {
        borderWidth: 1,
        borderColor: theme.colors.error
    },
})

export default connectActionSheet(InspectionGatePictures)
