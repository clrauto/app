import React, { useState } from 'react'
import {StyleSheet, View, Text, SafeAreaView} from "react-native";
import {theme} from "../core/theme";
import Button from "../components/Button";

const OutGate = ({ route, navigation }) => {
    const { inspection } = route.params

    return (
        <SafeAreaView style={styles.container}>
            <View style={{flex:1}}>
                <View style={{flex:1, padding: 15}}>
                    <Text style={{fontSize: 18}}>Do you want to start the Out Gate inspection?</Text>
                </View>
            </View>
            <View style={{ flexDirection: "row", alignItems:'center', justifyContent:'center'}}>
                <View style={styles.buttonContainer}>
                    <Button mode="contained"
                            style={{height: 65, justifyContent: 'center'}}
                            onPress={() => navigation.goBack()}
                    >
                        Cancel
                    </Button>
                </View>
                <View style={styles.buttonContainer}>
                    <Button mode="outlined"
                            style={{height: 65, justifyContent: 'center'}}
                            onPress={() => navigation.navigate('ChangeYard', {inspection: inspection})}
                    >
                        Out Gate
                    </Button>
                </View>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    buttonContainer: {
        flex:0.5,
        padding: 10
    }
})

export default OutGate
