import React, { useState } from 'react'
import Background from '../components/Background'
import Button from '../components/Button'
import DataManager from "../../DataManager";
import {Text} from "react-native-paper";
import RoundedTextInput from "../components/RoundedTextInput";
import {ActivityIndicator, Alert, StyleSheet, TouchableOpacity, View} from "react-native";
import {theme} from "../core/theme";
import {Ionicons} from "@expo/vector-icons";
import { BarCodeScanner } from 'expo-barcode-scanner';
import User from "../../Services/User";

const Dashboard = ({ route, navigation }) => {
    const [user, setUser] = useState({})
    const [vin, setVin] = useState('')
    const [hasPermission, setHasPermission] = useState(null);
    const [scanned, setScanned] = useState(false);
    const [scan, setScan] = useState(false);
    const [loading, setLoading] = useState(false);

    React.useEffect(() => {
        (async () => {
            const { status } = await BarCodeScanner.requestPermissionsAsync();
            setHasPermission(status === 'granted');

            DataManager.shared().getAccessToken(function (res) {
                if(!res) {
                    navigation.reset({
                        index: 0,
                        routes: [{ name: 'LoginScreen' }],
                    })
                } else{
                    DataManager.shared().getUserObject(function (user) {
                        if(user) {
                            setUser(user);
                            checkInspection();
                        }
                    });
                }
            });

            const unsubscribe = navigation.addListener('focus', () => {
                if (user) {
                    checkInspection();
                }
            });

            function checkInspection() {
                if (!route.params || (route.params && route.params.from !== 'LoadVehicle')) {
                    setLoading(true);

                    User.getCurrentInspection( function (response) {
                        setLoading(false);

                        if (response.vin) {
                            Alert.alert(
                                'Message',
                                'You have an inspection in progress for vin '+ response.vin +'.\n' +
                                '\n' +
                                'Do you want to continue with this inspection?',
                                [
                                    {
                                        text: 'No',
                                        onPress: () => { return false },
                                    },
                                    {
                                        text: 'Yes',
                                        onPress: () => { navigation.navigate('LoadVehicle', {vin: response.vin}) },
                                    }
                                ],
                                { cancelable: false },
                            );
                        }
                    }, function (error) {
                        setLoading(false);
                    });
                }
            }

            return () => {
                unsubscribe;
            };
        })();
    }, []);

    const handleBarCodeScanned = ({ type, data }) => {
        setScanned(true);
        setScan(false);
        setVin(data);
    };

    if (hasPermission === null) {
        return <Text>Requesting for camera permission</Text>;
    }
    if (hasPermission === false) {
        return <Text>No access to camera</Text>;
    }

    if (loading) {
        return (<ActivityIndicator size="large" color="#0000ff" style={{ marginTop: '50%' }} />)
    }

    return (
      <Background>
          {
              scan &&
              (<View style={{flex: 1, width: '100%'}}>
                  <View style={{flex:1}}>
                      <View style={{flex:1, flexDirection: 'row-reverse', marginTop: 0, zIndex: 99999}}>
                          <TouchableOpacity onPress={() => {setScan(false); setScanned(true)}}>
                              <Ionicons name="close" size={32} color={'#1d6db3'} />
                          </TouchableOpacity>
                      </View>
                  </View>
                      <BarCodeScanner
                          onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
                          style={[StyleSheet.absoluteFill, styles.container]}
                      >
                          <View style={styles.layerTop} />
                          <View style={styles.layerCenter}>
                              <View style={styles.layerLeft} />
                              <View style={styles.focused} />
                              <View style={styles.layerRight} />
                          </View>
                          <View style={styles.layerBottom} />
                      </BarCodeScanner>
              </View>)
          }
          {
              !scan &&
              (<View style={{width:'100%'}}>
                  <View style={{flexDirection: "row", alignItems: 'center', justifyContent: "center"}}>
                      <Text style={styles.title}>Enter VIN to search</Text>
                  </View>
                  <RoundedTextInput
                      label="VIN"
                      returnKeyType="next"
                      value={vin}
                      onChangeText={(text) => setVin(text)}
                      autoCapitalize="none"
                  />
                  <Button mode="contained"
                          onPress={() => navigation.navigate('LoadVehicle', {vin: vin})}
                          style={{height: 65, justifyContent: 'center'}}
                          icon={() => <Ionicons color={'#FFF'} size={20} name={'ios-car-sharp'} />}
                  >
                      Load Vehicle
                  </Button>
              </View>)
          }


      </Background>
    )
}

const opacity = 'rgba(0, 0, 0, .6)';
const styles = StyleSheet.create({
    title: {
        fontWeight: 'bold',
        fontSize: 20,
        color: theme.colors.gray,
        textAlign: 'center',
    },
    container: {
        flex: 1,
        flexDirection: 'column',
    },
    layerTop: {
        flex: 2,
        backgroundColor: opacity
    },
    layerCenter: {
        flex: 1,
        flexDirection: 'row'
    },
    layerLeft: {
        flex: 1,
        backgroundColor: opacity
    },
    focused: {
        flex: 10
    },
    layerRight: {
        flex: 1,
        backgroundColor: opacity
    },
    layerBottom: {
        flex: 2,
        backgroundColor: opacity
    },
})

export default Dashboard
