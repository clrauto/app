import * as React from 'react';
import {StyleSheet, Text, View} from 'react-native'
import { createDrawerNavigator, useIsDrawerOpen } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import {theme} from "../../core/theme";

const Drawer = createDrawerNavigator();

import {
    DrawerContentScrollView,
    DrawerItemList,
    DrawerItem
} from '@react-navigation/drawer';

import NavigatorView from "./RootNavigation";
import DataManager from "../../../DataManager";
import {useState} from "react";

const activeTintColor = '#FFF'
const inactiveTintColor = '#FFF'

function CustomDrawerContent(props, navigation) {
    const [user, setUser] = useState({})

    React.useEffect(
        React.useCallback(() => {
            DataManager.shared().getAccessToken(function (res) {
                if (res) {
                    DataManager.shared().getUserObject(function (userResponse) {
                        setUser(userResponse)
                    })
                }
            })
        }), [])

    const  onLogoutPressed = () => {
        DataManager.shared().unsetAuthorization(function() {
            props.navigation.reset({
                index: 0,
                routes: [{ name: 'LoginScreen' }],
            })
        });
    }

    return (
        <DrawerContentScrollView {...props} contentContainerStyle={{flex: 1,  flexDirection: 'column', justifyContent: 'space-between' }}>
            <View>
                <DrawerItem
                    label={({ focused, color }) => <Text style={{ color }}>{user.name + '\n' + user.email}</Text>}
                    icon={({ focused, color, size }) => <Ionicons color={color} size={32} name={'person-circle'} />}
                    style={{backgroundColor: theme.colors.secondary, width: '100%', marginLeft: 0, borderRadius: 0, paddingLeft: 8}}
                    activeTintColor={activeTintColor}
                    inactiveTintColor={inactiveTintColor}
                />
                <DrawerItemList {...props}
                                labelStyle={styles.labelItemStyle}
                                activeTintColor={activeTintColor}
                                inactiveTintColor={inactiveTintColor}
                />
            </View>
            <View>
                <DrawerItem
                    label="Sign Out"
                    labelStyle={styles.labelItemStyle}
                    onPress={onLogoutPressed}
                    activeTintColor={activeTintColor}
                    inactiveTintColor={inactiveTintColor}
                    icon={({ focused, color, size }) => <Ionicons color={color} size={size} name={'log-out'} />}
                />
            </View>
        </DrawerContentScrollView>
    );
}

const DrawerNavigation = (props) => {
    return (
            <Drawer.Navigator
                initialRouteName="Dashboard"
                drawerContent={(props) => <CustomDrawerContent {...props} />}
                drawerStyle={{
                    backgroundColor: theme.colors.primary
                }}
            >
                <Drawer.Screen
                    name="Home"
                    component={NavigatorView}
                    options={{
                        drawerIcon: config => <Ionicons color={'#FFF'} size={20} name={'home'} />
                    }}

                />
            </Drawer.Navigator>
    );
}

const styles = StyleSheet.create({
    labelItemStyle: {
        fontSize:16,
        fontWeight: 'bold'
    },
})

export default DrawerNavigation
