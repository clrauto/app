import React from 'react';
import { TouchableOpacity, Text } from 'react-native';


import Dashboard from '../Dashboard';
import ChangeYard from "../ChangeYard";
import {Ionicons} from "@expo/vector-icons";
import LoadVehicle from "../LoadVehicle";
import DeliverVehicle from "../DeliverVehicle";
import OutGate from "../OutGate";
import InspectionGate from "../InspectionGate";
import InspectionGatePictures from "../InspectionGatePictures";
import InspectionGatePictures2 from "../InspectionGatePictures2";
import InspectionGateSign from "../InspectionGateSign";
import Success from "../Success";

const headerLeftComponent = (props) => {
  return (
      <TouchableOpacity
          onPress={props.onPress}
          style={{
            paddingLeft: 10,
          }}
      >
        <Ionicons name="arrow-back" size={32} color="white" />
      </TouchableOpacity>
  )
}

const headerLeftComponent2 = (props) => {
  return (<Text ></Text>)
}

const headerBackground = require('../../../assets/clr-logo.png');

const headerLeftDeliver = (props) => {
  return (<Text style={{paddingLeft: 10, color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Deliver Vehicle</Text>)
}

const StackNavigationData = [
  {
    name: 'Dashboard',
    component: Dashboard,
    headerTitle: null,
    headerLeft: null,
    headerBackground: {source: headerBackground},
    headerTitleStyle: {
      color: '#FFF',
      fontSize: 20,
    },
  },
  {
    name: 'LoadVehicle',
    component: LoadVehicle,
    headerTitle: null,
    headerLeft: null,
    headerBackground: {source: headerBackground},
    headerTitleStyle: {
      color: '#FFF',
      fontSize: 20,
    },
  },
  {
    name: 'ChangeYard',
    component: ChangeYard,
    headerTitle: <Text style={{color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Change Yard</Text>,
    headerLeft: headerLeftComponent,
    headerRight: () => {}
  },
  {
    name: 'DeliverVehicle',
    component: DeliverVehicle,
    headerLeft: headerLeftDeliver,
    headerTitle: <Text></Text>,
    headerRight: () => {}
  },
  {
    name: 'InspectionGate',
    component: InspectionGate,
    headerLeft: headerLeftComponent2,
    headerTitle: <Text style={{color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Inspection - In/Out Gate</Text>,
    headerRight: null,
    inspection: true
  },
  {
    name: 'InspectionGatePictures',
    component: InspectionGatePictures,
    headerLeft: headerLeftComponent2,
    headerTitle: <Text style={{color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Inspection - In/Out Gate</Text>,
    headerRight: null,
    inspection: true
  },
  {
    name: 'InspectionGatePictures2',
    component: InspectionGatePictures2,
    headerLeft: headerLeftComponent2,
    headerTitle: <Text style={{color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Inspection - In/Out Gate</Text>,
    headerRight: null,
    inspection: true
  },
  {
    name: 'InspectionGateSign',
    component: InspectionGateSign,
    headerLeft: headerLeftComponent2,
    headerTitle: <Text style={{color: '#FFF', fontSize: 20, fontWeight: 'bold'}}>Inspection - In/Out Gate</Text>,
    headerRight: null,
    inspection: true
  },
  {
    name: 'Success',
    component: Success,
    headerTitle: null,
    headerLeft: null,
    headerBackground: {source: headerBackground},
    headerTitleStyle: {
      color: '#FFF',
      fontSize: 20,
    },
  },
]

export default StackNavigationData;
