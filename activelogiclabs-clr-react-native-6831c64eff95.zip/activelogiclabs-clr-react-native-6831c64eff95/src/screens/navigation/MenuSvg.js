import * as React from 'react';
import { Platform } from 'react-native';
import { SvgXml } from 'react-native-svg';

const width = Platform.isPad ? 45 : 35
const height = Platform.isPad ? 65 : 55
const xml = `
<svg enable-background="new 0 0 24 24" id="Layer_1" version="1.0" viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<line fill="none" stroke="#FFF" stroke-miterlimit="10" stroke-width="2" x1="2" x2="22" y1="12" y2="12"/>
<line fill="none" stroke="#FFF" stroke-miterlimit="10" stroke-width="2" x1="2" x2="22" y1="6" y2="6"/>
<line fill="none" stroke="#FFF" stroke-miterlimit="10" stroke-width="2" x1="2" x2="22" y1="18" y2="18"/></svg>
`;

export default () => <SvgXml xml={xml} width={width} height={height}/>;
