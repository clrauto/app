import 'react-native-gesture-handler';
import React from 'react';
import { Text } from 'react-native'
import { createStackNavigator } from '@react-navigation/stack';
import { TouchableOpacity, Platform, Image } from 'react-native';

import StackNavigationData from './stackNavigationData';
import { Ionicons } from '@expo/vector-icons';
import MenuSvgComponent from "./MenuSvg";
import {theme} from "../../core/theme";

const Stack = createStackNavigator();

const NavigatorView = (props) => {

  function openMenu() {
    props.navigation.toggleDrawer();
  }

  function loadVehicle() {
      props.navigation.navigate('Dashboard');
  }

  const headerLeftComponentMenu = () => (
    <TouchableOpacity
      onPress={() => openMenu()}
      style={{
          paddingLeft: 10,
        }}
    >
      <MenuSvgComponent></MenuSvgComponent>
    </TouchableOpacity>    
  )

    const headerLeftComponent2 = () => {
        return (
            <TouchableOpacity
                onPress={() => props.navigation.navigate('Dashboard')}
                style={{
                    paddingLeft: 10,
                }}
            >
                <Ionicons name="md-log-out-outline" size={32} color="white" />
            </TouchableOpacity>
        )
    }

  const headerStyle = Platform.isPad ? { backgroundColor: theme.colors.primary, height: 85 } : { backgroundColor: theme.colors.primary}
  const headerBackground = require('../../../assets/clr-logo-white.png');

  return (
    <Stack.Navigator
        initialRouteName="Dashboard"
        screenOptions={{ gestureEnabled: false }}
    >
      {StackNavigationData.map((item, idx) => (
        <Stack.Screen
          key={`stack_item-${idx+1}`}
          name={item.name} 
          component={item.component} 
          options={({ route }) => ({
              headerTitle: (props) => ( // App Logo
                  (route.params && route.params.inspection &&
                   (<Text style={{color: '#FFF', fontSize: 18.5, fontWeight: 'bold'}}>{route.params.inspection.inspection_type} Inspection</Text>))
                   || (item.headerTitle || <Image
                      style={{width: 80, height: 80}}
                      source={require('../../../assets/clr-logo-white.png')}
                      resizeMode='contain'
                  />)
              ),
              headerTitleAlign: 'center',
              headerTitleStyle: [{flex: 1, textAlign: 'center', alignSelf: 'center'}, item.headerTitleStyle],
              headerLeft: item.headerLeft || headerLeftComponentMenu,
              headerStyle,
          })}
        />
      ))}
    </Stack.Navigator>
  );
}

export default NavigatorView
