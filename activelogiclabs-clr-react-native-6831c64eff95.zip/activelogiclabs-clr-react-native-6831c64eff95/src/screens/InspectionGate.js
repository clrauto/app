import React, { useState, useReducer, useRef } from 'react'
import { ActionSheetProvider, connectActionSheet, useActionSheet } from '@expo/react-native-action-sheet'
import { ActivityIndicator, StyleSheet, View, Text, SafeAreaView, Image, FlatList, Alert, TouchableOpacity, TextInput, Modal } from "react-native";
import {theme} from "../core/theme";
import Button from "../components/Button";
import {Ionicons} from "@expo/vector-icons";
import ProgressBar from "../components/ProgressBar";
import Inspection from "../../Services/Inspection";
import * as ImagePicker from 'expo-image-picker';
import mime from "mime";
import SlideText from "../components/SlideText";

function itemsReducer(state, newItem) {
    const index = state.findIndex(record => record.id === newItem.id);
    if (index >= 0) {
        const update = [...state];
        newItem.hasOwnProperty('value') ? update[index].value = newItem.value : '';
        newItem.hasOwnProperty('input') ? update[index].input = newItem.input : '';
        newItem.hasOwnProperty('damage_input') ? update[index].damage_input = newItem.damage_input : '';
        newItem.hasOwnProperty('file_path') ? update[index].file_path = newItem.file_path : null;
        newItem.hasOwnProperty('file') ? update[index].file = newItem.file : null;
        newItem.hasOwnProperty('additional_input') ? update[index].additional_input = newItem.additional_input : '';
        return update;
    }
    return [...state, newItem];
}

const Item = ({ item, requiredItems, onSetItem, selectedItemValue, openOptionsModal }) => {
    const { showActionSheetWithOptions } = useActionSheet();

    function onOpenActionSheet(item) {
        const options = ['Take a photo', 'Choose a photo', 'Cancel'];
        const destructiveButtonIndex = 2;
        const cancelButtonIndex = 2;

        showActionSheetWithOptions(
            {
                title: 'Select an image',
                options,
                cancelButtonIndex,
                destructiveButtonIndex,
                showSeparators: true,
                useModal: true,
                titleTextStyle: {fontWeight: 'bold', alignSelf: 'center', fontSize: 20}
            },
            buttonIndex => {
                if (buttonIndex == 0) {
                    openCamera(item).then(r => console.log(r))
                }
                if (buttonIndex == 1) {
                    pickImage(item).then(r => console.log(r))
                }
            },
        );
    };

    async function pickImage(item) {
        const {status} = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status === 'granted') {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All,
                aspect: [4, 3],
                quality: 1,
            });

            if (!result.cancelled) {
                onSetItem(item, result.uri)
            }
        }
    };

    async function openCamera(item) {
        const {status} = await ImagePicker.requestCameraPermissionsAsync();
        if (status === 'granted') {
            ImagePicker.launchCameraAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                aspect: [1, 1],
                quality: 1
            }).then(r => {
                if (!r.cancelled) {
                    onSetItem(item, r.uri)
                }
            })
        }
    };

    function checkRequired(item) {
        return requiredItems.filter((option) => option.id == item.id) >= 0 ? false : true
    }

    return (
        <View
            style={[styles.item, {'flexDirection': item.type.title === 'textarea' ? "column" : "row"},
                checkRequired(item) ? styles.highlightedItem : '']}>
            <Text style={[styles.title, item.type.title === 'textarea' ? styles.textarea : {maxWidth: '60%'}]}>{item.title}</Text>
            {
                (
                    item.type.title === 'textarea' &&
                    <View style={styles.textarea}>
                        <TextInput multiline
                                   style={styles.textareainput}
                                   onChangeText={text => onSetItem(item, text)}
                                   value={selectedItemValue(item)}
                                   key={`textarea-${item.id}`}
                        />
                    </View>
                )
            }
            {
                item.type.title != 'textarea' &&
                (<View style={[styles.actions, {width: '40%'}]}>
                    {
                        (
                            (item.type.title === 'select' || item.type.title === 'radio') &&
                            <View style={{paddingLeft: 5, width: '95%'}}>
                                <TouchableOpacity
                                    onPress={() => {openOptionsModal(item)}}
                                    >
                                    {
                                        selectedItemValue(item) &&
                                        (<View style={[styles.buttonContainerP, {padding: 5, justifyContent: 'flex-end',}]}>
                                            <Text style={{marginRight: 5}}>{selectedItemValue(item)}</Text>
                                            <Ionicons name={"chevron-down"} size={ 20 } color="gray"/>
                                        </View>)
                                    }
                                    {
                                        !selectedItemValue(item) &&
                                        (<View style={{alignItems: 'flex-end', marginRight: 10}}>
                                            <Ionicons name={"chevron-down"} size={ 35 } color="gray"/>
                                        </View>)
                                    }

                                </TouchableOpacity>
                            </View>
                        )
                    }
                    {
                        (
                            item.type.title === 'photo' &&
                            <View style={{flexDirection: "row-reverse"}}>
                                <TouchableOpacity
                                    onPress={() => onOpenActionSheet(item)}
                                    style={styles.attach}>
                                    <Ionicons name="camera" size={25} color={theme.colors.primary}/>
                                </TouchableOpacity>
                                {selectedItemValue(item) != null &&
                                <Image source={{uri: selectedItemValue(item)}} style={{width: 70, height: 50}}/>}
                            </View>
                        )
                    }
                    {
                        (
                            item.type.title === 'file' &&
                            <View style={{flexDirection: "row-reverse"}}>
                                <TouchableOpacity
                                    onPress={() => pickDocument(item)}
                                    style={styles.attach}>
                                    <Ionicons name="md-cloud-upload" size={25} color={theme.colors.primary}/>
                                </TouchableOpacity>
                                {selectedItemValue(item) != null &&
                                <Ionicons name="checkmark" size={50} color={theme.colors.primary}/>}
                            </View>
                        )
                    }
                </View>)
            }
        </View>);
}

const InspectionGate = ({route, navigation}) => {
    const {inspection} = route.params
    const [started, setStarted] = useState(false)
    const [step, setStep] = useState(0)
    const [inspectionSaved, setInspectionSaved] = useState({})
    const [items, setItems] = useReducer(itemsReducer, []);
    const [itemInputs, setItemInputs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [stepsTotal, setStepsTotal] = useState(3)
    const [requiredItems, setRequiredItems] = useState([])
    const [damageOptions, setDamageOptions] = useState(false)
    const [additionalOptions, setAdditionalOptions] = useState(false)
    const [selectedItem, setSelectedItem] = useState(null)
    const [showOptionsModal, setShowOptionsModal] = useState(false)
    const flatListRef = useRef();

    const renderItem = ({ item }) => <Item
        item={item}
        requiredItems={requiredItems}
        onSetItem={onSetItem}
        selectedItemValue={selectedItemValue}
        openOptionsModal={openOptionsModal}
    />;

    React.useEffect(() => {
        (async () => {
            if (!started) {
                if (inspection.items.length == 0) {
                    Alert.alert("The inspection template has no assigned items.")
                    navigation.navigate('Dashboard');
                } else {
                    setItemInputs(inspection.item_inputs)
                    setStepsTotal(Math.ceil((inspection.items.length / 12)))

                    if (!inspection.id) {
                        Inspection.store(inspection, function (response) {
                            inspection.id = response.id
                            setInspectionSaved(response)
                            setItemInputs(response.item_inputs)
                            setStarted(true)
                        }, function (error) {
                            console.log("Error saving inspection", error)
                            Alert.alert("Something went wrong. Please try again.")
                            navigation.goBack()
                        })
                    } else {
                        setStarted(true)
                    }
                }
            }
        })();
    }, []);

    if (!started) {
        return (
            <ActivityIndicator size="large" color="#0000ff" style={{marginTop: '50%'}}/>
        )
    }

    function onSetItem(item, value = null, damage = false, additional = false) {
        let file = null
        let fileName = '';
        if (item.type.title == 'photo' || item.type.title == 'file') {
            const newImageUri = "file:///" + (value).split("file:/").join("");
            fileName = newImageUri.split("/").pop();
            file = {
                uri: newImageUri,
                type: mime.getType(newImageUri),
                name: fileName
            }
        }

        if (!additional && !damage) {
            setItems({
                id: item.id,
                value: value,
                inspection_item_id: item.id,
                input: item.type.title == 'photo' || item.type.title == 'file' ? fileName : value,
                file_path: item.type.title == 'photo' || item.type.title == 'file' ? fileName : null,
                file: file,
            });
        }

        if (additional) {
            setItems({
                id: item.id,
                inspection_item_id: item.id,
                additional_input: value
            });
        }

        if (damage) {
            setItems({
                id: item.id,
                inspection_item_id: item.id,
                damage_input: value
            });
        }
    }

    function setPickerValue(item, value, additional = false, damage = false) {

        if (!value && !additional && !damage) {
            onSetItem(item, value, true, true);
        }

        onSetItem(item, value, damage, additional);

        if (damage && item.additional_input_required === 1) {
            if (value === null) {
                onSetItem(item, null, false, true);
            } else {
                setDamageOptions(false)
                setAdditionalOptions(true)
            }
            return;
        }

        if (item.require_damage_input_on_input_value === value && !additional && value !== '' && value !== null) {
            //setSelectedItem(item)
            setDamageOptions(true)
        } else {
            if (!additional && !damage) {
                onSetItem(item, null, true, true);
            }
            if (value !== null) {
                setSelectedItem(null)
                setDamageOptions(false)
                setAdditionalOptions(false)
                setShowOptionsModal(false)
            }
        }
    }

    function selectedItemValue(selItem, additional = false, damage = false) {

        let index = items.findIndex(item => item.id === selItem.id);

        if(index >= 0) {
            return additional ? items[index].additional_input : (damage ? items[index].damage_input : items[index].value)
        } else {
            if (itemInputs) {
                index = itemInputs.findIndex(item => item.inspection_item_id === selItem.id);
                if(index >= 0) {
                    return itemInputs[index].path_url ? itemInputs[index].path_url : (additional ? itemInputs[index].additional_input : (damage ? itemInputs[index].damage_input : itemInputs[index].input))
                }
            }
            return null;
        }
    }

    function openOptionsModal(item)
    {
        setDamageOptions(false)
        setSelectedItem(item)
        setShowOptionsModal(true)
    }

    async function next() {
        setLoading(true)
        const allItems = inspection.items;
        const listItems = allItems.slice((step * 12), ((step * 12) + 12));
        setRequiredItems([])

        const result = listItems.filter((itm) => {
            const index = items.findIndex((itmS) => itm.id === itmS.id)
            const indexInp = itemInputs ? itemInputs.findIndex((itmS) => itm.id === itmS.inspection_item_id) : -1

            if (index < 0 && indexInp < 0) {
                return itm
            } else {
                if (index >= 0 && (items[index].input === '' || items[index].input === null)) return itm
            }
        })

        if (result.length > 0) {

            setRequiredItems(result);
            Alert.alert("Complete all items before proceeding.");
            setLoading(false);

        } else {
            await Inspection.inputs(inspection.id ?? inspectionSaved.id, items, function (response) {
                setItemInputs(response.item_inputs);
                setLoading(false);
                step >= (stepsTotal - 1) ? navigation.navigate('InspectionGatePictures', {inspection: inspection}) : setStep(step + 1);
                flatListRef.current.scrollToOffset({animated: false, offset: 0})
            }, function (error) {
                console.log("Error saving item inputs", error)
                Alert.alert("Something went wrong. Please try again.")
                setLoading(false)
            })

        }
    }

    function ItemOption({item}, option)
    {
        return (
            <TouchableOpacity
                onPress={() => { setPickerValue(selectedItem, item.value, option === 'additional', option === 'damage') }}>
                <View style={[styles.buttonContainerP, {padding: 10}, selectedItemValue(selectedItem, option === 'additional', option === 'damage') === item.value && styles.selectedItem]}>
                    <Text style={{color: '#000'}}>
                        {item.value}
                    </Text>
                </View>
            </TouchableOpacity>
        );
    }

    function closeModal()
    {
        let index = items.findIndex(item => item.id === selectedItem.id);
        if (index >=0 && items[index].require_damage_input_on_input_value === selectedItem.input && (!items[index].hasOwnProperty('damage_input') || items[index].damage_input === null)) {
            onSetItem(selectedItem, null)
        }
        setDamageOptions(false)
        setAdditionalOptions(false)
        setSelectedItem(null)
        setShowOptionsModal(false);
    }

    return (
        <ActionSheetProvider>
            <SafeAreaView style={styles.container}>
                <View style={{flex: 1}}>
                    <View style={{flex: 1, padding: 8}}>
                        <ProgressBar step={(step + 1)} total={(stepsTotal + 3)} inspection={inspection}></ProgressBar>
                        <FlatList
                            ref={flatListRef}
                            data={inspection.items.length > 0 ? inspection.items.slice((step * 12), ((step * 12) + 12)) : []}
                            renderItem={renderItem}
                            keyExtractor={item => item.id.toString()}
                            removeClippedSubviews={false}
                        />
                    </View>
                </View>
                <View style={styles.buttonContainerP}>
                    <View style={styles.buttonContainer}>
                        <Button mode="outlined"
                                style={styles.outlineButton}
                                onPress={() => step == 0 ? navigation.goBack() : setStep(step - 1)}
                                uppercase={false}
                                icon={() => <Ionicons name="arrow-back" size={25} color={theme.colors.primary}/>}
                        >
                            Back
                        </Button>
                    </View>
                    <View style={styles.buttonContainer}>
                        <Button mode="contained"
                                uppercase={false}
                                style={{height: 65, justifyContent: 'center', borderRadius: 5}}
                                onPress={() => next()}
                                icon={() => <Ionicons name="arrow-forward" size={25} color="white"/>}
                                contentStyle={{flexDirection: 'row-reverse'}}
                                disabled={loading}
                        >
                            {loading ? 'Loading...' : 'Next'}
                        </Button>
                    </View>
                </View>
                <SlideText inspection={inspection} navigation={navigation}/>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={showOptionsModal}>
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <View style={{width: '100%', flexDirection: 'row-reverse', marginBottom: 10}}>
                                <TouchableOpacity
                                    onPress={() => { closeModal() }}>
                                    <Ionicons name="close" size={25} color={theme.colors.primary} />
                                </TouchableOpacity>
                            </View>
                            {
                                selectedItem && !damageOptions && !additionalOptions &&
                                (<View>
                                    <TouchableOpacity onPress={() => setPickerValue(selectedItem, null) } style={[styles.buttonContainerP, {padding: 10}]}>
                                        <Text>Clear Selection</Text>
                                    </TouchableOpacity>
                                    <FlatList
                                        data={selectedItem.array_options}
                                        renderItem={(item) => ItemOption(item, null)}
                                        keyExtractor={item => item.value}/>
                                </View>)
                            }
                            {
                                damageOptions &&
                                (<View>
                                    <TouchableOpacity onPress={() => setPickerValue(selectedItem, null, false, true)  } style={[styles.buttonContainerP, {padding: 10}]}>
                                        <Text style={styles.titleModal}>Select a damage (clear selection)</Text>
                                    </TouchableOpacity>
                                    <FlatList
                                        data={selectedItem.array_damage_options}
                                        renderItem={(item) => ItemOption(item, 'damage')}
                                        keyExtractor={item => item.value}
                                    />
                                </View>)
                            }
                            {
                                (
                                    additionalOptions &&
                                    <View>
                                        <TouchableOpacity onPress={() => setPickerValue(selectedItem, null, true)  } style={[styles.buttonContainerP, {padding: 10}]}>
                                            <Text style={styles.titleModal}>Additional (clear selection)</Text>
                                        </TouchableOpacity>
                                        <FlatList
                                            data={selectedItem.additional_array_options}
                                            renderItem={(item) => ItemOption(item, 'additional')}
                                            keyExtractor={item => item.value}/>
                                    </View>
                                )
                            }
                        </View>
                    </View>
                </Modal>
            </SafeAreaView>
        </ActionSheetProvider>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        backgroundColor: '#FFF'
    },
    buttonContainerP: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 0
    },
    buttonContainer: {
        flex: 0.5,
        paddingLeft: 10,
        paddingRight: 10
    },
    outlineButton: {
        height: 65,
        justifyContent: 'center',
        borderRadius: 5, borderWidth: 2,
        borderColor:
        theme.colors.primary
    },
    item: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "space-between",
        padding: 0,
        marginVertical: 3,
        backgroundColor: '#f5f3f3'
    },
    title: {
        paddingLeft: 8,
    },
    textarea: {
        width: '100%',
        padding: 10
    },
    textareainput: {
        height: 80,
        borderWidth: 1,
        backgroundColor: 'white',
        borderColor: theme.colors.lightgrayb,
        marginLeft: 10,
        marginRight: 10,
        textAlignVertical: "top"
    },
    yesButton: {
        height: 50,
        width: 72,
        alignItems: 'center',
        justifyContent: 'center'
    },
    borderRight: {
        borderRightWidth: 1,
        borderRightColor: theme.colors.lightgrayb,
    },
    selectedItem: {
        backgroundColor: theme.colors.lightgray,
    },
    centeredView: {
        flex: 1,
        marginTop: '50%',
    },
    modalView: {
        margin: 10,
        backgroundColor: 'white',
        padding: 10,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    actions: {
        justifyContent: 'center',
        height: 48,
        flexDirection: "row",
        alignItems: 'center'
    },
    attach: {
        alignItems: 'center',
        alignContent: 'center',
        padding: 10,
        borderRightWidth: 1,
        borderRightColor: theme.colors.lightgrayb,
        width: 72
    },
    highlightedItem: {
        borderWidth: 1,
        borderColor: theme.colors.error
    },
    titleModal: {
        fontSize: 16,
        color: theme.colors.primary
    }
})

export default connectActionSheet(InspectionGate)