import Config from "../../Config";

export const LoginUrl = Config.serverUrl + 'auth/login'
