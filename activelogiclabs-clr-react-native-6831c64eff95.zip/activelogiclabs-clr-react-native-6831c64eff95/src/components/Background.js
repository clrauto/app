import React from 'react'
import { StyleSheet, KeyboardAvoidingView, ScrollView, Dimensions } from 'react-native'
import { theme } from '../core/theme'

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

const Background = ({ children }) => (
  <ScrollView
    style={styles.scrollView}
    contentStyle={styles.contentContainer}
  >
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      {children}
    </KeyboardAvoidingView>
  </ScrollView>
)

const styles = StyleSheet.create({
  scrollView: {
    height: '100%',
    width: '100%',
    alignSelf: 'center',
    flex: 1,
    backgroundColor: '#FFF',
    padding: 15
  },
  contentContainer: {
    flexGrow: 1,
    padding: 20
  },
  background: {
    flex: 1,
    width: '100%'
  },
  container: {
    height: windowHeight - 74,
    width: '100%',
    maxWidth: 340,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
})

export default Background
