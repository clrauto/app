import React from 'react'
import {StyleSheet, View} from "react-native";
import Button from "./Button";
import {theme} from "../core/theme";
import {Ionicons} from "@expo/vector-icons";

const ButtonsContainer = ({ next, navigation, inspection, finish, onNext, enabled, loading, onBack = null, ...props }) => (
    <View style={styles.container}>
        <View style={styles.buttonContainer}>
            <Button mode="outlined"
                    style={styles.outlineButton}
                    onPress={onBack ? onBack : () => navigation.goBack()}
                    uppercase={false}
                    icon={() => <Ionicons name="arrow-back" size={25} color={theme.colors.primary} />}
            >
                Back
            </Button>
        </View>
        <View style={styles.buttonContainer}>
            <Button mode="contained"
                    uppercase={false}
                    style={{height: 65, justifyContent: 'center', borderRadius: 5}}
                    onPress={onNext}
                    icon={() => <Ionicons name="arrow-forward" size={25} color="white" />}
                    contentStyle={{flexDirection: 'row-reverse'}}
                    disabled={loading && loading===true}
            >
                {loading && loading===true ? 'Loading...' : 'Next'}
            </Button>
        </View>
    </View>
)

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems:'center',
        justifyContent:'space-between',
        padding: 0,
        backgroundColor: 'white'
    },
    buttonContainer: {
        flex:0.5,
        paddingLeft: 10,
        paddingRight: 10
    },
    outlineButton: {
        height: 65,
        justifyContent: 'center',
        borderRadius: 5,
        borderWidth: 2,
        borderColor:
        theme.colors.primary
    }
})

export default ButtonsContainer
