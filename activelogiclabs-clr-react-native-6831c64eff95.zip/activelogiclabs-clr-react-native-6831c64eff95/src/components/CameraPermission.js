import React, {useState} from 'react'
import {Modal, Text, View, TouchableOpacity} from 'react-native';
import * as Permissions from 'expo-permissions';
import { Camera } from 'expo-camera';
import {Ionicons} from "@expo/vector-icons";
import Button from "./Button";


const CameraPermission = ({ route, navigation, visible, ...props }) => {
    const [isAuthorized, setIsAuthorized] = useState(false)
    const [cameraReady, setCameraReady] = useState(false)
    const [type, setType] = useState(Camera.Constants.Type.back)
    const cameraRef = React.useRef();

    React.useEffect(() => {
        (async () => {
            const { status } = await Permissions.getAsync(Permissions.CAMERA);
            if (status == 'granted') {
                const { status } = Permissions.askAsync(Permissions.CAMERA_ROLL)
                if (status == 'granted') {
                    setIsAuthorized(true);
                }
            }
        })();
    }, []);


    const getPermissionAsync = async () =>
    {
        const { status } = await Permissions.askAsync(Permissions.CAMERA);
        if (status !== 'granted') {
            const { status } = Permissions.askAsync(Permissions.CAMERA_ROLL)
            if (status !== 'granted') {
                alert('Sorry, we need camera permissions to make this work!');
                return;
            }
        }

        setIsAuthorized(true);
    };


    return (
            <Modal animationType={'fade'} visible={visible }>
                { !isAuthorized && (
                    <View style={{ flex:1, alignItems: 'center', justifyContent: 'center'}}>
                        <View style={{ paddingLeft:20, paddingRight:20 }}>
                            <Text style={{ textAlign: 'center', fontSize:28, marginBottom:20}}>We need access to your camera</Text>
                            <Text style={{ textAlign: 'center', fontSize:14 }}>Please click the “Grant Access” button below and grant us access to use your camera so we can allow you to take photos.</Text>
                        </View>

                        <View style={{ marginTop:20 }}>
                            <Button mode="contained"
                                    style={{height: 65, justifyContent: 'center'}}
                                    uppercase={false}
                                    onPress={getPermissionAsync}
                            >
                                Grant Access
                            </Button>
                        </View>
                    </View>
                )}

                { isAuthorized && (
                    <Camera
                        ref={cameraRef}
                        style={{ flex:1 }}
                        type={type}
                        onCameraReady={() => {
                            setCameraReady (true )
                        }}>

                        { (!cameraReady) && (<Text style={{ textAlign: 'center', color:'white', marginTop: 60 }}>Just a moment...</Text>) }

                        <View style={{
                            flex: 1,
                            flexDirection: 'column',
                            justifyContent: 'flex-end',
                            padding : 40
                        }}>

                            <View style={{
                                backgroundColor: 'transparent',
                                flexDirection: 'row',
                                justifyContent: 'space-between'
                            }}>

                                <TouchableOpacity
                                    style={{ marginTop:15 }}
                                    onPress={() => {
                                        setType (type === Camera.Constants.Type.back ? Camera.Constants.Type.front : Camera.Constants.Type.back);
                                    }}>
                                    <Ionicons name='refresh' size={30} color={'white'} />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    onPress={async () => {

                                        let photo = await cameraRef.current.takePictureAsync();

                                        props.onPhotoTaken(photo)

                                    }}>
                                    <Ionicons name='camera' size={60} color={'white'} />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    style={{ marginTop:15 }}
                                    onPress={() => {

                                        props.onCancel()

                                    }}>
                                    <Ionicons name='close' size={30} color={'white'} />
                                </TouchableOpacity>

                            </View>

                        </View>
                    </Camera>
                )}

            </Modal>
        );
}
export default CameraPermission
