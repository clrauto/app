import React, {useState} from 'react'
import {ActivityIndicator, Alert, StyleSheet, Text, TouchableOpacity} from 'react-native'
import { theme } from '../core/theme'
import Inspection from "../../Services/Inspection";
import {Ionicons} from "@expo/vector-icons";
import Button from '../components/Button';

const SlideText = ({inspection, navigation, button = false, ...props}) => {
    const [text, setText] = useState('Tap to Cancel')

    function cancelInspection() {
        Alert.alert(
            'Confirmation',
            'Are you sure you would like to quit this inspection? This will clear any inspection data entered',
            [
                {
                    text: 'No',
                    onPress: () => { return false },
                },
                {
                    text: 'Yes',
                    onPress: () => { cancel() },
                }
            ],
            { cancelable: false },
        );
    }

    function cancel()
    {
        setText('Wait...')
        Inspection.cancel(inspection.id, function (response) {
            navigation.navigate('Dashboard', {from: 'Cancel'});
        }, function (error) {
            console.log("Error canceling inspection", error)
            setText('Tap to Cancel')
            Alert.alert("Something went wrong. Please try again.")
        })
    }

    if(text === 'Wait...') {
        return (
            <ActivityIndicator size="large" color="#0000ff" style={{height: 40}}/>
        )
    }

    if (button) {
        return (<Button
                    mode="outlined"
                    style={styles.cancelButton}
                    onPress={() => cancelInspection()}
                    uppercase={false}
                    disabled={text === 'Wait...'}
                >
                    <Text style={{color: theme.colors.gray}}>Cancel Inspection</Text>
                </Button>);
    } else {
        return (
            <TouchableOpacity
                onPress={() => cancelInspection()}
                style={styles.back}
            >
                <Text style={styles.text}>{text}</Text>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    back: {
        backgroundColor: 'white',
    },

    text: {
        fontSize: 16,
        color: theme.colors.gradient,
        textAlign: 'center',
        marginBottom: 10
    },

    cancelButton: {
        height: 55,
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: theme.colors.gray,
        paddingLeft: 20,
        paddingRight: 20,
        color: theme.colors.error,
    }
})

export default SlideText