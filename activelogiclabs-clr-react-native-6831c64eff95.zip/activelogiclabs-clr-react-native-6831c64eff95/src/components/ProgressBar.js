import React from 'react'
import {StyleSheet, Text, View} from 'react-native'
import {theme} from "../core/theme";

const ProgressBar = ({ step, inspection }) => (
    <View>
        {
            inspection &&
            (<View style={[styles.padding, {backgroundColor: theme.colors.gradient, opacity: 0.8, margin:-8, marginBottom: 10}]}>
                <Text style={styles.description}>VIN: {inspection.vehicle_vin}</Text>
                <Text style={styles.description}>Make: {inspection.vehicle_make}</Text>
            </View>)
        }
        <Text style={{fontWeight:'bold'}}>Step {step} of {(Math.ceil(inspection.items.length/12) + 3)}</Text>
        <View style={styles.bar}>
            <View style={{
                width:  ((100/(Math.ceil(inspection.items.length/12) + 3)) * step) + '%',
                backgroundColor: theme.colors.primary
            }}></View>
        </View>
    </View>
)

const styles = StyleSheet.create({
    bar: {flexDirection:'row',
        height: 22,
        marginBottom: 8,
        backgroundColor:theme.colors.lightgray,
        borderWidth: 2,
        borderColor: theme.colors.lightgrayb
    },
    padding: {
        padding: 10
    },
    fontSize: {
        fontSize: 16
    },
    description: {
        fontSize: 18,
        color: theme.colors.textWhite
    }
})

export default ProgressBar
