import * as t from './actionTypes';
import { Alert } from 'react-native';
import {LoginUrl} from "../constans/api"; // to show alerts in app

const setLoginState = (loginData) => {
    return {
        type: t.SET_LOGIN_STATE,
        payload: loginData,
    };
};

export function login (loginInput) {
    const { email, password } = loginInput;
    console.log('test2')
    return (dispatch) => {  // don't forget to use dispatch here!
        console.log('test3')
        return fetch(LoginUrl, {
            method: 'POST',
            headers: {  // these could be different for your API call
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(loginInput),
        })
            .then((response) => response.json())
            .then((json) => {
                console.log('Response', json)
                if (json.msg === 'success') { // response success checking logic could differ
                    dispatch(setLoginState({ ...json, userId: email })); // our action is called here
                } else {
                    Alert.alert('Login Failed', 'Username or Password is incorrect');
                }
            })
            .catch((err) => {
                Alert.alert('Login Failed', 'Some error occured, please retry');
                console.log(err);
            });
    };
};


