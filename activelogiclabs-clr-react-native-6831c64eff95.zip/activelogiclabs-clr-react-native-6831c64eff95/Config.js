export const Config = {
    _serverUrl: "https://portal.clrautotransport.com/api/",
    serverUrl: "https://portal.clrautotransport.com/api/",
};

export default Config
